package com.example.navday1cw

import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {



@Composable
fun Page1(rem2 : String?){
    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize()
    ) {
        Text("We are at page1 $rem2")
    }
}
    @Composable
    fun Page2(rem3 : String?){
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            Text("We are page3 $rem3")
        }
    }

    @Composable
    fun Home(rem1: NavHostController) {

        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()

        ) {
            var name by remember { mutableStateOf("") }
            var mob by remember { mutableStateOf("") }
            Text("Welcome to Home page")

            TextField(value = name, onValueChange = {
                name=it
            })

            TextField( value = mob, onValueChange = {
                mob = it
            } )

            Button( onClick = {
                //abc should be same as we define NavHost
                    rem1.navigate(route = "abc/$name")
            }) {
                Text("Good")
            }

            Button(onClick = {
                rem1.navigate(route = "pagee2/$mob")
            }){
                Text("Bad")
            }


        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val rem = rememberNavController()

            NavHost(rem, startDestination = "hme") {

                composable("hme") {
                    Home( rem)
                }

               composable(route = "abc/{hhh}") {
                    var b = it.arguments?.getString("hhh")

                   Page1( b)
               }

                composable(route = "pagee2/{qqq}"){
                    var c = it.arguments?.getString( "qqq")

                    Page2( c)
                }


            }



        }
    }
}

