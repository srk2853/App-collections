package com.example.weatherapp_task2

data class WeatherUiState(
    val isLoading: Boolean = false,
    val data: WeatherResponse? = null,
    val error: String? = null
)