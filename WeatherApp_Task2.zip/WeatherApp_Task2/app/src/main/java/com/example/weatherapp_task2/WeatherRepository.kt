package com.example.weatherapp_task2


class WeatherRepository {

    private val api = WeatherInterf.getInstance()

    suspend fun getWeather(city: String): WeatherResponse {
        return api.getWeatherByCity(
            city,
            "a6ea090d1f474d6abdee5db6552ff501"
        )
    }
}
