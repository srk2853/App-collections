package com.example.weatherapp_task2

import androidx.compose.ui.input.key.Key
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherInterf {


    //defining the end points
    @GET("weather")
    suspend fun getWeatherByCity(
        @Query("q") cityName: String,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): WeatherResponse


    companion object {
        var api: WeatherInterf? = null

        fun getInstance(): WeatherInterf {

            if (api == null) {
                api = Retrofit.Builder()
                    .baseUrl("https://api.openweathermap.org/data/2.5/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build().create(WeatherInterf::class.java)


            }
            return api!!
        }
    }
}
