package com.example.weatherapp_task2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.weatherapp_task2.ui.theme.WeatherApp_Task2Theme
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            val viewModel = androidx.lifecycle.viewmodel.compose.viewModel<WeatherViewModel>()
            val uiState by viewModel.uiState.collectAsState()

            var city by remember { mutableStateOf("") }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("Enter City") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(onClick = {
                    viewModel.fetchWeather(city)
                }) {
                    Text("Search")
                }

                Spacer(modifier = Modifier.height(20.dp))

                when {
                    uiState.isLoading -> Text("Loading...")
                    uiState.error != null -> Text(uiState.error!!, color = Color.Red)
                    uiState.data != null -> WeatherCard(uiState.data!!)
                }
            }
        }
    }
}

@Composable
fun WeatherCard(weather: WeatherResponse) {
    androidx.compose.material3.Card(
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("📍 ${weather.name}, ${weather.sys.country}")
            Text("🌡 Temp: ${weather.main.temp} °C")
            Text("🤔 Feels Like: ${weather.main.feels_like} °C")
            Text("💧 Humidity: ${weather.main.humidity}%")
            Text("🌬 Wind: ${weather.wind.speed} m/s")
            Text("☁ ${weather.weather[0].description}")
        }
    }
}
