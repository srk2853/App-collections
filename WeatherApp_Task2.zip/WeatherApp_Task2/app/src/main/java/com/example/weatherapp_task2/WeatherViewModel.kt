package com.example.weatherapp_task2

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class WeatherViewModel : ViewModel() {

    private val repository = WeatherRepository()

    private val _uiState = MutableStateFlow(WeatherUiState())
    val uiState: StateFlow<WeatherUiState> = _uiState

    fun fetchWeather(city: String) {
        viewModelScope.launch {
            _uiState.value = WeatherUiState(isLoading = true)

            try {
                val response = repository.getWeather(city)
                _uiState.value = WeatherUiState(data = response)
            } catch (e: Exception) {
                _uiState.value = WeatherUiState(
                    error = e.localizedMessage ?: "Something went wrong"
                )
            }
        }
    }
}
