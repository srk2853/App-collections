package com.example.hw_31st_march

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var  name : EditText
    lateinit var mob : EditText
    lateinit var adddtxt : EditText
    lateinit var mailltxt : EditText

    lateinit var  regbtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        name = findViewById(R.id.nametxt)
        mob = findViewById(R.id.mobtxt)
        adddtxt = findViewById(R.id.addtxt)
        mailltxt = findViewById(R.id.mailtxt)
        regbtn = findViewById(R.id.regbtn)

        regbtn.setOnClickListener {

            var intent = Intent(this, confirmation_page::class.java)
            intent.putExtra( "namm",name.text.toString())
            intent.putExtra("mobi",mob.text.toString())

            startActivity(intent)
        }


    }
}