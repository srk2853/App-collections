package com.example.hw_31st_march

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class confirmation_page : AppCompatActivity() {

    lateinit var  nam : TextView
    lateinit var mob : TextView

    lateinit var  sub : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_confirmation_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        nam = findViewById(R.id.sname)
        mob = findViewById(R.id.smob)

        sub = findViewById(R.id.sbtn)

        val nameget = intent.getStringExtra("namm")
        nam.text = if(nameget!= null){
            "Name : $nameget"
        }else{
            ""
        }

        val mobile = intent.getStringExtra("mobi")?: "No mobile no provided"
        mob.text = if(mobile!= null){
            "Mobile No : $mobile"
        }else {
            " "
        }








    }
}