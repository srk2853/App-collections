package com.example.otpsms

import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var batteryReceiver : BatteryCharge
    private lateinit var aeroplanReceiver : AeroplaneModeReciever

    private lateinit var btn_success : Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        val batteryText = findViewById<TextView>(R.id.batteryText)
        val valueStatus = findViewById<TextView>(R.id.valueStatus)

        btn_success = findViewById(R.id.btn_Success)

        aeroplanReceiver = AeroplaneModeReciever(valueStatus)
        val filter2 = IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        registerReceiver(aeroplanReceiver,filter2)



        batteryReceiver = BatteryCharge(progressBar,batteryText)
        val filter = IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
        registerReceiver(batteryReceiver,filter)

        if(checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE)!= android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(arrayOf(android.Manifest.permission.READ_PHONE_STATE),101)
        }

        //succes button
        btn_success.setOnClickListener {
//            val intent = Intent(applicationContext, MainActivity2::class.java)
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        unregisterReceiver(batteryReceiver)
    }


}