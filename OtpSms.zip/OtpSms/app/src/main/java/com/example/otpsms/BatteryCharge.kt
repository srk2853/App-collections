package com.example.otpsms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.widget.ProgressBar
import android.widget.TextView

class BatteryCharge (

    private val progressBar: ProgressBar,
    private val batteryText : TextView

) : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL,-1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)

        if(level != -1 && scale != -1){
            val batteryPerecent = level/scale.toFloat()
            progressBar.progress = (batteryPerecent * 100).toInt()
            batteryText.text = "Battery : ${batteryPerecent* 100}%"
        }

    }
}