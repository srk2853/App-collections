package com.example.otpsms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.telecom.TelecomManager
import android.telephony.TelephonyManager

class PhoneTrigger : BroadcastReceiver() {

    //using a companion object or a global reference is better for Receivers, because
    // the class is re-instantiated every time a broadcast hits{

    companion object{
        private var mediaPlayer : MediaPlayer ?= null
}
    override fun onReceive(context: Context, intent: Intent) {
        //get the current status of the phone
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)

        if(state == TelephonyManager.EXTRA_STATE_RINGING){
            //1.clean up an old player
            mediaPlayer?.stop()
            mediaPlayer?.release()

            //2. Trigger the new audio
            mediaPlayer = MediaPlayer.create(context,R.raw.devi_prasad_hai)
            mediaPlayer?.start()
        }

        //optional1: Stop the music when the call is answered or missed
        if(state == TelephonyManager.EXTRA_STATE_OFFHOOK || state == TelephonyManager.EXTRA_STATE_IDLE){
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }
}