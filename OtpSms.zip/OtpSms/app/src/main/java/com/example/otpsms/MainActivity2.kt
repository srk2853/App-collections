package com.example.otpsms

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.otpsms.databinding.ActivityMain2Binding
import com.example.otpsms.databinding.ActivityMain2Binding.inflate


class MainActivity2 : AppCompatActivity() {

    lateinit var bd : ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        bd = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(bd.root)

        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        bd.btnSuccess.setOnClickListener {
            bd.btnSuccess.text= "unSucess"
        }
    }
}