package com.example.otpsms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer

class VolumeMaster : BroadcastReceiver() {
    private  var mediaPlayer : MediaPlayer? = null
    override fun onReceive(context: Context, intent: Intent) {
        //this method is called when the BroadcastReceiver is receiving an Intent Broadcast

        if(intent.action == "android.media.VOLUME_CHANGED_ACTION"){
            val currentVolume = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE",0)

            //2. get the max volume for this stream(to know what is 100%)
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

            //3. lOGIC - if current volumen is max, play the sound

            if(currentVolume == maxVolume){
                playSuccessSound(context)
            }else{
                mediaPlayer?.stop()
                mediaPlayer?.release()
            }
        }

    }

    private fun playSuccessSound(context : Context){
        //stop any previous sound if any of it is playing
        mediaPlayer?.stop()
        mediaPlayer?.release()

        //initialise and play (Using a built-in system sound for this example)
        mediaPlayer = MediaPlayer.create(context,R.raw.lele_lele)
        mediaPlayer?.start()
    }
}