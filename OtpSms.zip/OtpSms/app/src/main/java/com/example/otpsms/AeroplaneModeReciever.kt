package com.example.otpsms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.TextView

class AeroplaneModeReciever(private val valueStatus: TextView) : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {

        if(intent.action == Intent.ACTION_AIRPLANE_MODE_CHANGED){

            //extract the state "boolean" state from system intent
            val isEnabled = intent.getBooleanExtra("state",false)

            //update the text on the screen

            if(isEnabled){
                valueStatus.text = "ON"
                valueStatus.setTextColor((android.graphics.Color.RED))
            }else{
                valueStatus.text = "OFF"
                valueStatus.setTextColor(android.graphics.Color.GREEN)
            }
        }
    }
}