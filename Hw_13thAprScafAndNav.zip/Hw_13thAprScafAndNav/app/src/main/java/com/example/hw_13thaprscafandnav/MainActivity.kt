package com.example.hw_13thaprscafandnav


import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontVariation.Settings
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@OptIn(ExperimentalMaterial3Api::class)

class MainActivity : ComponentActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val context = currentCont
        setContent {
            val navController = rememberNavController()
            Scaffold(
                floatingActionButton = {
                    FloatingActionButton({}, Modifier.padding(16.dp)) {
                        Text("+")
                    }
                },
                topBar = {

                    TopAppBar(

                        title = {
                            Column(
                                modifier = Modifier
                                    .background(Color.Yellow)
                                    .fillMaxSize()
                            ) {
                                Text(
                                    "My App",
                                    modifier = Modifier.padding(16.dp),


                                )

                            }
                                },

                        actions = {
                            IconButton(onClick = { /* action */ }) {
                                Icon(Icons.Default.Add, contentDescription = "Add")
                            }
                        }


                    )
                },
                bottomBar = {
                    BottomAppBar {
                        //Bottom navigation
                        NavigationBar {
                            //currentBackStackEntry Represents the current screen in the navigation stack
                            //destination refers to the NavDestination object
                            val currentRoute =
                                navController.currentBackStackEntry?.destination?.route

                            NavigationBarItem(
                                selected = currentRoute == "home",
                                onClick = {
//                                    navController.navigate("home") {
//                                        launchSingleTop = true
                                    //launchSingleTop = true  --> It prevents creating multiple copies of the same screen on the navigation
                                    // back stack if that screen is already on top.
//                                    }

                                   // navController.navigate("home")

                                    context

                                },
                                icon = { Icon(Icons.Default.Home, null) },
                                label = { Text("Home") }
                            )

                            NavigationBarItem(
                                selected = currentRoute == "web",
                                onClick = {
                                    navController.navigate("web")
                                },
                                icon = {
                                    Icon(
                                        painter = painterResource(R.drawable.img),
                                        contentDescription = "Profile",
                                        tint = Color.Unspecified
                                    )
                                },
                                label = { Text("Web") }
                            )
                            NavigationBarItem(
                                selected = false,
                                onClick = {
                                       // navController.navigate(route = "sett")
                                },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") }
                            )
                        }
                    }
                },

            ) { padding ->
                NavHost(
                    navController = navController,
                    startDestination = "dashboard",
                    modifier = Modifier.padding(padding)
                ) {


                    composable("dashboard") {
                        Home(navController)   // current screen with text fields
                    }


                    composable("home") {
                            HomePage()
                    }

                    composable(route = "sett") {
                        SettingsPage()
                    }


                    composable("abc/{name}") {
                        Text("ABC Page")
                    }

                    composable("pagee2/{mob}") {
                        Text("Page 2")
                    }

                    composable("web") {


                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ){
                            SimpleWebView(
                                "https://www.google.com/"
                            )
                        }

                    }
                }

            }

            /*
            Surface(
                color = Color.LightGray,
                shape = RoundedCornerShape(12.dp),
                shadowElevation = 8.dp,
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "This is a Surface",
                    modifier = Modifier.padding(16.dp)
                )
            }

            */






        }
    }
}


@Composable
fun SimpleWebView(url: String) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                webViewClient = WebViewClient()
            }
        },
        update = { webView ->
            webView.loadUrl(url)
        }
    )
}

@Composable
fun Home(rem1: NavHostController) {

    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize()

    ) {
        var name by remember { mutableStateOf("") }
        var mob by remember { mutableStateOf("") }
        Text("Welcome to Home page")

        TextField(value = name, onValueChange = {
            name=it
        })

        TextField( value = mob, onValueChange = {
            mob = it
        } )

        Button( onClick = {
            //abc should be same as we define NavHost
            rem1.navigate(route = "abc/$name")
        }) {
            Text("Good")
        }



    }
}


@Composable
fun HomePage() {
    Column(
        modifier = Modifier.fillMaxSize().background(Color.Green),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Welcome Home",
            color = Color.White,
            fontSize = 25.sp

        )
    }
}

@Composable
fun SettingsPage(){

    Column(
       modifier = Modifier.fillMaxSize().background(Color.Cyan)
    ) {
        Text(
            text = "This is setting page",
            fontSize = 25.sp
        )
    }

}
