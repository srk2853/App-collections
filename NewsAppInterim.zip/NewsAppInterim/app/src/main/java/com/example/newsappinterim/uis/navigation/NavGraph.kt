package com.example.newsappinterim.uis.navigation

import androidx.compose.runtime.Composable
import  androidx.navigation.compose.composable

import androidx.navigation.compose.composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.NavHostController
import com.example.newsappinterim.data.datadss.local.Article
import com.example.newsappinterim.uis.screens.DetailScreen
import com.example.newsappinterim.uis.screens.HomeScreen
import com.example.newsappinterim.uis.screens.NewsViewModel
import com.example.newsappinterim.uis.screens.SearchScreen
import com.google.gson.Gson
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class Screen(val route: String){

    object  Home : Screen("home")

    object Detail : Screen("detail/{articleJson}"){

        fun createRoute(article: Article):String{
            //convert the whole article to a single string
            val json = Gson().toJson(article)

            val encodedJson = URLEncoder.encode(json, StandardCharsets.UTF_8.toString())
            return "detail/$encodedJson"
        }
    }

    object Search : Screen("search")
}

@Composable
fun NavGraph(
    navController: NavHostController,
    viewModel: NewsViewModel
){
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ){
        //Home Screen
        composable(route = Screen.Home.route){
            HomeScreen(viewModel = viewModel,
                onArticleClick = { article ->
                    navController.navigate(Screen.Detail.createRoute(article))

                },
                onSearchClick = {
                    navController.navigate((Screen.Search.route)) //navigation to search screen
                })
        }

        //Detail screen

        composable(route = Screen.Detail.route){ backStackEntry ->
           //1.Get the encoded JSON string

            val encodedJson = backStackEntry.arguments?.getString("articleJson")?:""

            //2. DECODE it back to normal JSON(this removes the '+' and '%20' signs)

            val decodedJson = URLDecoder.decode(encodedJson, StandardCharsets.UTF_8.toString())

            //3. Convert it back to your Article object

            val article = Gson().fromJson(decodedJson,Article::class.java)
            DetailScreen(article = article,onBack = {navController.popBackStack()})

        }

        //search Screnn
        composable(Screen.Search.route){
            SearchScreen(viewModel = viewModel
                ){ article ->
                navController.navigate(Screen.Detail.createRoute(article))

            }
        }


    }
}

/*
✔ Centralizes navigation
✔ Uses sealed class for safety
✔ Handles URL encoding
✔ Shares ViewModel across screens
✔ Supports back navigation
 */