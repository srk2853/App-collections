package com.example.newsappinterim.uis.screens

import android.R
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.example.newsappinterim.data.datadss.local.Article
import com.example.newsappinterim.data.datadss.repository.NewsRepository
import com.example.newsappinterim.uis.common.Resource
import androidx.compose.runtime.State
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch


/*
        What is a ViewModel?

        Holds UI‑related data
        Survives configuration changes
        Talks to Repository
        Uses Coroutines

 */
class  NewsViewModel(private val repository: NewsRepository): ViewModel(){

    //The underscore means “this is a private, mutable backing variable”
    //and it is NOT meant to be accessed directly by the UI.
    private val _articles = mutableStateOf<Resource<List<Article>>>(Resource.Loading())

    val articles: State<Resource<List<Article>>> = _articles

    //1. The list of categories for the tabs
    val categories = listOf(
        "General","Business","Technology","Sports","Health","Entertainment","Science"
    )

    //2.Track the selected tabs

    private val _selectedCategory = mutableStateOf("General")

    val selectedCategory: State<String> = _selectedCategory

    //Updae the fetch news to set the selected category
    fun fetchNews(category: String){

        _selectedCategory.value = category //track the active tab
        viewModelScope.launch {
            _articles.value = Resource.Loading()
            val result = repository.getTopHeadline(category.lowercase())
            if(result.isNotEmpty()){
                _articles.value = Resource.Success(result)
            }else{
                _articles.value = Resource.Error("Couldn't fetch $category news")
            }
        }
    }

    //add a new state for search results

    private  val _searchResults = mutableStateOf<Resource<List<Article>>>(Resource.Success(emptyList()))

    val searchResults: State<Resource<List<Article>>> = _searchResults


    fun searchNews(query: String){
        if(query.isEmpty()) return

        viewModelScope.launch {
            _searchResults.value = Resource.Loading()
            try{
                //we use same respository but different method
                val result = repository.searchNews(query)
                if(result.isNotEmpty()){
                    _searchResults.value = Resource.Success(result)

                }else{
                    _searchResults.value = Resource.Error("No result found for '${R.attr.query}' ")
                }
            }catch(e: Exception){
                _searchResults.value = Resource.Error(e.message ?: "Search faliled")
            }
        }
    }

}


class NewsViewModelFactory(private val  repository: NewsRepository) : ViewModelProvider.Factory{
    override fun <T : androidx.lifecycle.ViewModel>create(modelClass: Class<T>): T{
        if(modelClass.isAssignableFrom(NewsViewModel::class.java)){
            @Suppress("UNCHECKED_CAST")
            return NewsViewModel(repository) as T
        }
        throw IllegalArgumentException("unknown view model class")
    }
}

/*
ViewModelFactory is used to create ViewModels with constructor dependencies like Repository. Since Android can only create ViewModels with no‑arg constructors by default, Factory provides a way to inject dependencies in a lifecycle‑aware manner.


        One‑Line Summary
        ✅ NewsViewModelFactory provides the repository to NewsViewModel
        ✅ Required when ViewModel has constructor parameters
        ✅ Core part of MVVM architecture

 */
/*
        Why suppress warning?

        Kotlin cannot fully verify generic casting at runtime
        Safe here because of the isAssignableFrom check
 */

/*
In Android, a ViewModelFactory is used to create ViewModel objects that have constructor parameters.
👉 By default, Android can create only ViewModels with no‑argument constructors.
👉 If your ViewModel needs a Repository, you must use a Factory.
 */