package com.example.newsappinterim.uis.screens

import android.R
import android.text.Layout
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.newsappinterim.data.datadss.local.Article

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(article: Article, onBack:() -> Unit) {

    //state to toggle between Summary and web view
    var showWebView by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            if (!showWebView) {
                DetailBottomBar(onReadFullClick = { showWebView = true })
            }
        }
    ) { padding ->
        if (showWebView) {
            //1. Create a variable to hold the WebView reference
            var webView: WebView? by remember { mutableStateOf(null) }

            //2. Intercept the back gesture
            BackHandler(enabled = showWebView) {
                if (webView?.canGoBack() == true) {
                    webView?.goBack() //Go back in the website's history

                } else {
                    showWebView = false //if no more history , go back to the summary view

                }
            }

            //Full web view mode

            Column(modifier = Modifier.fillMaxSize()) { //romove padding to fix height

                TopAppBar(
                    title = { Text("Full Article", style = MaterialTheme.typography.titleSmall) },
                    navigationIcon = {
                        IconButton(onClick = {
                            //manual top-bar back button also checks history
                            if (webView?.canGoBack() == true) {
                                webView?.goBack()
                            } else {
                                showWebView = false
                            }
                        }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "back")

                        }
                    }
                )


                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )

                            webViewClient = WebViewClient()
                            //Allow Javascript as most news site need it to function and navigate
                            settings.javaScriptEnabled = true
                            loadUrl(article.url)
                            webView = this //store the reference
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )


            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 80.dp) //spce for bottom bar
            ) {
                //Header image section
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    AsyncImage(
                        model = article.urlToImage,
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.DarkGray),
                        contentScale = ContentScale.Crop
                    )

                    //Back and share button overlaid on image
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.background(Color.Black.copy(0.3f), CircleShape)
                        ) {
                            Icon(
                                Icons.Default.ArrowBack,
                                contentDescription = null,
                                tint = Color.White
                            )

                            IconButton(
                                onClick = {/* Handle Share */ },
                                modifier = Modifier.background(Color.Black.copy(0.3f), CircleShape)
                            ) {
                                Icon(
                                    Icons.Default.Share,
                                    contentDescription = null,
                                    tint = Color.White
                                )

                            }

                        }
                    }


                    //Content Section
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = article.category.uppercase(),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = article.title,
                            style = MaterialTheme.typography.headlineLarge, //merriweather
                            lineHeight = 32.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        //Author Row

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier.size(40.dp).clip(CircleShape)
                                    .background(Color.LightGray),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(article.sourceName.take(1))
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(

                            ) {
                                Text(text = article.sourceName, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${article.publishedAt.take(10)}.4 min read",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }

                        Spacer(Modifier.height(24.dp))

                        Text(
                            text = article.description ?: "No description available.",
                            style = MaterialTheme.typography.bodyLarge,
                            lineHeight = 26.sp,
                            color = Color.Gray
                        )
                    }


                }


            }
        }


    }
}



@Composable
fun DetailBottomBar(onReadFullClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp).navigationBarsPadding(),
            verticalAlignment = Alignment.CenterVertically
        ){
            Button(
                onClick = onReadFullClick,
                modifier = Modifier.weight(1f).height(50.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Read Full Article ↗")
            }

            Spacer(modifier = Modifier.width(16.dp))
            //Bookmark/Save Toggle Button
            FilledIconButton(
                onClick = {},
                modifier = Modifier.size(50.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.BookmarkBorder,contentDescription = null)
            }
        }
    }
}





