package com.example.newsappinterim.uis.common

sealed class Resource<T>(val data: T? = null,val message: String ?=null){

    class Success<T>(data : T): Resource<T>(data)

    class Error<T>(message: String, data:T ?= null): Resource<T>(data,message)

    class Loading<T>(data: T? = null) : Resource<T>(data)
}

/*
        What is a sealed class?

        A sealed class restricts inheritance
        All subclasses must be defined in the same file
        Makes when expressions safe (no else required)

✅ Perfect for finite states (Success / Error / Loading)
 */

/*
Resource<T> is a sealed class used to represent loading, success, and error states of data in a type-safe and reusable way,
commonly used in MVVM Android apps.
 */