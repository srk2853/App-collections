package com.example.newsappinterim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.example.newsappinterim.data.datadss.remote.RetrofitClient
import com.example.newsappinterim.data.datadss.repository.NewsRepository
import com.example.newsappinterim.ui.theme.NewsAppInterimTheme
import com.example.newsappinterim.uis.navigation.NavGraph
import com.example.newsappinterim.uis.screens.NewsViewModel
import com.example.newsappinterim.uis.screens.NewsViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        //Manual instantiation since we aren't using Hilt yet
        val apiService = RetrofitClient.api
        val repository = NewsRepository(apiService)
        val factory = NewsViewModelFactory(repository)
        setContent {
            NewsAppInterimTheme {

                val navController = rememberNavController() //create the controller
                //This creates the viewModel using our own custom factory
                val viewModel : NewsViewModel = viewModel(factory = factory)

                Surface(color = MaterialTheme.colorScheme.background) { }
                    //use navGraph instead of calling Homescreen directly
                NavGraph(navController = navController, viewModel = viewModel)

                }
            }
        }
    }

