package com.example.newsappinterim.uis.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.newsappinterim.data.datadss.local.Article

/*
ArticleCard is a reusable Jetpack Compose component that displays a news article as a Material 3 card
with an image, headline,
 and source, handling clicks and adaptive UI styling.
 */

@Composable
fun ArticleCard(
    article: Article,
    onClick: (Article) -> Unit
){
    Card(
        onClick = {onClick(article)},
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        /*
        Uses app’s surface color
Automatically supports light & dark mode
         */
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        /*
            Adds subtle shadow
            Creates material depth
         */
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
    ){
        Row(
            modifier = Modifier
                .padding(12.dp)
                .height(100.dp)
        ){

            //for this we need to add coil in dependency
            //Thumbnail image
            AsyncImage(
                model = article.urlToImage,
                contentDescription = null,
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(8.dp)),
                /*
                    Image fills space
                    Excess parts are cropped
                    Prevents stretching


                 */
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween

            ) {

                //Headline
                Text(
                    text= article.title,
                    style = MaterialTheme.typography.headlineMedium,
                    /*
                    Prevents long titles from breaking layout
                    Adds ... when text exceeds 3 lines
                     */

                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )

                //Metadata (Source and published time)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ){
                    Text(
                        text = article.sourceName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}