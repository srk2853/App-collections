@file:kotlin.OptIn(ExperimentalMaterial3Api::class)

package com.example.newsappinterim.uis.screens

import androidx.annotation.OptIn
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.newsappinterim.data.datadss.local.Article
import com.example.newsappinterim.uis.common.Resource
import com.example.newsappinterim.uis.component.ArticleCard

/*
This HomeScreen is a state‑driven Jetpack Compose UI that displays news using MVVM principles, with tabs,
pull‑to‑refresh, loading/error handling, and clean Material 3 design.
 */



@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3Api::class,
    ExperimentalMaterial3Api::class, ExperimentalMaterial3Api::class,
    ExperimentalMaterial3Api::class, ExperimentalMaterial3Api::class,
    ExperimentalMaterial3Api::class, ExperimentalMaterial3Api::class
)
@Composable
fun HomeScreen(viewModel: NewsViewModel,
               onArticleClick : (Article) -> Unit,
               onSearchClick : () -> Unit){

    val state = viewModel.articles.value
    val selectedCat = viewModel.selectedCategory.value

    //this runs only once when the homescreen enter the composition

    LaunchedEffect(Unit) {
        if(state !is Resource.Success){
            //only fetch if we don't have data yet
            viewModel.fetchNews("General")
        }
    }

    Scaffold(
       topBar = {
           //Wrap Appbar and tabs in a column
           CenterAlignedTopAppBar(
               actions = {
                   IconButton(onClick = onSearchClick) {
                       Icon(Icons.Default.Search, "Search")
                   }
               },
               title = { Text("NewsNow", style = MaterialTheme.typography.headlineLarge) }

           )

           ScrollableTabRow(
               selectedTabIndex = viewModel.categories.indexOf(selectedCat),
               containerColor = MaterialTheme.colorScheme.surface,
               contentColor = MaterialTheme.colorScheme.primary,
               edgePadding = 16.dp,
               divider = {}  //remove default driver for cleaner look
           ) {

               viewModel.categories.forEach { category ->
                   Tab(
                       selected = selectedCat == category,
                       onClick = { viewModel.fetchNews(category) },
                       text = {
                           Text(
                               text = category,
                               style = MaterialTheme.typography.bodyMedium,
                               fontWeight = if (selectedCat == category) FontWeight.Bold else FontWeight.Normal

                           )
                       }

                   )
               }
           }



       }


    )
    {
        padding ->
        val isRefreshing = state is Resource.Loading && state.data!=null

        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { viewModel.fetchNews(selectedCat) },
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (state) {
                is Resource.Loading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }

                is Resource.Success -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        items(state.data ?: emptyList()) { article ->
                            ArticleCard(
                                article = article,
                                onClick = { onArticleClick(article) }
                            )

                        }

                    }
                }

                is Resource.Error -> {
                    Text(
                        text = state.message ?: "Unknown Error",
                        modifier = Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }




}

