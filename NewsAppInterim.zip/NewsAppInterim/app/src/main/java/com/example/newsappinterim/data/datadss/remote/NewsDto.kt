package com.example.newsappinterim.data.datadss.remote

//This matches top level json response

data class NewsResponseDto(
    val status: String,
    val totalResults: Int,
    val articles: List<ArticleDto>
)

//this mathces each article in the "articles " list

data class ArticleDto(
    val source: SourceDto,
    val author:String?,
    val title: String,
    val description: String?,
    val url: String,
    val urlToImage: String?,
    val publishedAt: String,
    val content: String?
)

data class SourceDto(
    val name: String
)