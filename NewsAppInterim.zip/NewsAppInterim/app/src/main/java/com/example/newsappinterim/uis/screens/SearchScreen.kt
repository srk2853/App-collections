package com.example.newsappinterim.uis.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.newsappinterim.data.datadss.local.Article
import com.example.newsappinterim.uis.common.Resource
import com.example.newsappinterim.uis.component.ArticleCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: NewsViewModel,
    onArticleClick: (Article) -> Unit
){
    var searchQuery  by remember { mutableStateOf("") }
    val searchState = viewModel.searchResults.value

    Scaffold(
        topBar = {
            TopAppBar(title = {Text("Search News")})
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            //Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {searchQuery = it},
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                placeholder = { Text("Search topics...")},
                trailingIcon = {
                    IconButton(onClick = { viewModel.searchNews(searchQuery)}) {
                        Icon(Icons.Default.Search,contentDescription = "Search")
                    }
                },
                singleLine = true

            )
            //Result list

            Box(modifier = Modifier.fillMaxSize()){
                when(searchState){
                    is Resource.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    is Resource.Success -> {
                        LazyColumn {
                            items(searchState.data ?: emptyList()) { article ->
                                ArticleCard(
                                    article = article,
                                    onClick = { onArticleClick(article) })

                            }
                        }

                    }
                    is Resource.Error -> Text(searchState.message?:"Error", Modifier.align(Alignment.Center))
                }
            }
        }

    }
}