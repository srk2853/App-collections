package com.example.newsappinterim.data.datadss.repository

import com.example.newsappinterim.data.datadss.local.Article
import com.example.newsappinterim.data.datadss.remote.ArticleDto
import com.example.newsappinterim.data.datadss.remote.NewsApiService


/*
What is a Repository?

Single source of truth
Decides where data comes from (API / DB / Cache)
Separates data logic from UI


 */


class NewsRepository (
    private val api: NewsApiService
){

    //An API key is a unique string of letters and numbers that acts as a secret identifier for an application or user when making requests to an API.
   // Think of it as a digital access badge — without it, the API won’t let you in.
    private val apiKey = "62f250af1bd84724ae748686e5606ec3" //paste your news api key here

    suspend fun getTopHeadline(category: String):List<Article>{

        return  try{
            val response = api.getTopHeadline(category,apiKey)
            /*
              dto is
                 Raw data from API
                Nullable
                Not clean for UI usage
             */
            //convert DTOs to our UI Model
            response.articles.map { dto -> dto.toArticle(category) }
        }catch (e: Exception){
            emptyList() //we will handle error better later
        }
    }

    suspend fun searchNews(query: String):List<Article>{
        return try{
            val response = api.searchNews(query,apiKey)
            response.articles.map{it.toArticle("Search")}

        }catch(e: Exception){
            emptyList()
        }
    }
}


//Extension function to transform the data

fun ArticleDto.toArticle(category: String): Article{
    return Article(
        url = this.url,
        title = this.title,
        author=this.author?:"Unknown",
        sourceName = this.source.name,
        description=this.description,
        urlToImage=this.urlToImage,
        publishedAt = this.publishedAt,
        content= this.content,
        category=category
    )
}