package com.example.jetpaccomposetask1

import android.content.Context
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jetpaccomposetask1.ui.theme.JetpacComposeTask1Theme
import java.util.jar.Attributes


class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxSize()


            ) {
                MainScreen(applicationContext)
            }


        }
    }
}

@Composable
fun MainScreen(context: Context){
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf( "") }
    var phone by remember { mutableStateOf("") }
    var res by remember { mutableStateOf("") }

    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize()
    ) {
        TopData(
            name = name,
            email = email,
            phone = phone,
            onNameChange = {name = it},
            onEmailChange = {email = it},
            onPhoneChange = {phone = it}
        )

        ButtonPart(
                context = context,
                name = name,
                email = email,
                phone = phone,
                res = res,
                onResultChange = {res =it}


        )
    }
}



@Composable
fun TopData(
    name: String,
    email : String,
    phone : String,
    onNameChange : (String) -> Unit,
    onEmailChange : (String ) -> Unit,
    onPhoneChange: (String) -> Unit
){
    Column() {


        TextField(value = name ,
            onValueChange = onNameChange,
            label = { Text("Full Name")}
        )

        TextField(value = email,
            onValueChange = onEmailChange,
            label = { Text("Email")}
        )

        TextField(value = phone,
            onValueChange = onPhoneChange,
            label = {Text("Phone")}
        )
    }

}

@Composable
fun ButtonPart(
        context: Context,
        name : String,
        phone : String,
        email: String,
        res : String,
        onResultChange : (String) -> Unit
){

    Row() {
        Button(
            onClick = {
               Toast.makeText(context,"Name : $name , phone: $phone , email: $email", Toast.LENGTH_LONG).show()
            },
            shape = RoundedCornerShape(size=16.dp) ,
            modifier = Modifier.padding(top = 20.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)

        ){
            Text("Toast")

        }
        //In Jetpack Compose, state must be owned and modified by the composable that created it,
        // then passed down along with a setter callback.
        Button(
            onClick = {
                onResultChange(
                    "Name : $name\n Mobile : $phone\n Email: $email"
                )
            },
            shape = RoundedCornerShape(size = 16.dp),
            modifier = Modifier.padding(top = 20.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            Text("TextView")
        }
    }
    Text( text = res  )

}


