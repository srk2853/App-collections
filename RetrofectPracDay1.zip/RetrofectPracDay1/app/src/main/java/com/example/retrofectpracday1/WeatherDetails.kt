package com.example.retrofectpracday1

data class WeatherDetails(

    val weather: List<Weather>?=null
)
