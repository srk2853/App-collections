package com.example.retrofectpracday1

import androidx.compose.ui.input.key.Key
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface Deba {

    @GET(value = "weather/")
    suspend fun getWeatherByCity(
        @Query("q") cityName: String,
        @Query(value = "appid") apiKey: String
    ): WeatherDetails

    companion object{
        var api : Deba? = null

        fun getInstance():Deba {
            api = Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(Deba::class.java)

            return api!!
        }
    }
}