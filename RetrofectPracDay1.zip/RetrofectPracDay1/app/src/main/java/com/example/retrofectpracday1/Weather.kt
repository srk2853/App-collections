package com.example.retrofectpracday1

data class Weather(
    val description: String,
    val icon: String,
    val id: Int,
    val main: String
)
