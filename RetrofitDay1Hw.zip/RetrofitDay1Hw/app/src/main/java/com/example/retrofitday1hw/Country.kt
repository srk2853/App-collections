package com.example.retrofitday1hw


data class CountryDetails(
    val error: Boolean,
    val msg: String,
    val data: List<Country>
)

data class Country(
    val country: String,
    val code: String,
    val iso3: String,
    val populationCounts: List<PopulationCount>
)

data class PopulationCount(
    val year: Int,
    val value: Long
)

