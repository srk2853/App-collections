package com.example.retrofitday1hw

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface Ram {

    @GET("countries/population")
    suspend fun getAllCountries(): CountryDetails

    companion object{
        var api: Ram? = null

        fun getInstance(): Ram{
            api= Retrofit.Builder()
                .baseUrl("https://countriesnow.space/api/v0.1/")
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(Ram::class.java)


            return api!!
        }
    }

}