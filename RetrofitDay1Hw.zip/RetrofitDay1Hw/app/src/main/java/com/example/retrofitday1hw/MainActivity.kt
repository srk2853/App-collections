package com.example.retrofitday1hw

import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.retrofitday1hw.ui.theme.RetrofitDay1HwTheme
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            var result  by remember { mutableStateOf<CountryDetails?>(null) }


            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxSize()
            ) {

                LaunchedEffect(Unit) {
                    result = Ram.getInstance().getAllCountries()
                }


                Text(
                    result?.data?.getOrNull(56)?.country?:"Loading.."
                )


                CountryList(result)



            }





            }
        }



}


@Composable
fun CountryList(result: CountryDetails?) {
    if (result == null) {
        Text("Loading...")
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(result.data) { country ->
            Text(
                text = "Country: ${country.country}",
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}


//val arabWorld = result?.data
//    ?.firstOrNull { it.country == "Arab World" }
//
//LazyColumn {
//    items(arabWorld?.populationCounts ?: emptyList()) { pop ->
//        Text(
//            text = "Year: ${pop.year} → Population: ${pop.value}"
//        )
//    }
//}


