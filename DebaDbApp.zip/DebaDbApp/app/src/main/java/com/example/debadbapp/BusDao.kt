package com.example.debadbapp

import androidx.room.Dao
import androidx.room.Insert

@Dao
interface BusDao {

    @Insert
    suspend fun savebus(bus : Bus)



}