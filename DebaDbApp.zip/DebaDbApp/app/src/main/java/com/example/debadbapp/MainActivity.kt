package com.example.debadbapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.room.Room
import com.example.debadbapp.ui.theme.DebaDbAppTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            val scp = rememberCoroutineScope()

            val db = Room.databaseBuilder(
                applicationContext,
                BusDatabase::class.java,
                "BusDB"
            ).build()


            Button({

                scp.launch {

                    val singlebusdata = Bus(0,"Chennai Express","SRK786","Khan")

                    db.busdao().savebus(singlebusdata)

                }

            }) {
                Text("save bus")
            }





        }
    }
}
