package com.example.debadbapp

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


@Database(entities = [Bus::class], version = 1)
abstract class BusDatabase : RoomDatabase() {
    abstract fun busdao(): BusDao
}