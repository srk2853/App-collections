package com.example.debadbapp

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity
data class Bus(
    @PrimaryKey(autoGenerate = true)
    var BusId: Int = 0,

    @ColumnInfo(name = "BusName")  // column name 1
    var BusName : String,


    @ColumnInfo(name = "BusNumber")  // column name 2
    var BusNumber : String,


    @ColumnInfo(name = "DriverName")  // column name 3
    var DriverName : String
)
