package com.example.hw_two_april

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.TextView

class MyReceiver(private val tv : TextView) : BroadcastReceiver() {


    override fun onReceive(context: Context, intent: Intent) {
        // This method is called when the BroadcastReceiver is receiving an Intent broadcast.

        val isOn = intent?.getBooleanExtra("state", false) ?: false
        tv.text = if (isOn)
            "Airplane Mode ON"
          else "Airplane Mode OFF"

    }
}