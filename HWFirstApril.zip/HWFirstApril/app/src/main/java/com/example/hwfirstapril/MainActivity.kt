package com.example.hwfirstapril

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    fun catf(view: View){
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.middle, BlankFragment())
            .commit()
    }

    fun cowf(view: View) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.middle, BlankFragment2())
            .commit()
    }

    fun dogf(view: View) {
        getSupportFragmentManager().beginTransaction().replace(R.id.middle, BlankFragment3()).commit()
    }

    fun dhoomf(view: View) {
        getSupportFragmentManager().beginTransaction().replace(R.id.middle, BlankFragment4()).commit()
    }

    fun lionf(view: View) {
        getSupportFragmentManager().beginTransaction().replace(R.id.middle, BlankFragment5()).commit()
    }

    fun ramf(view: View) {
        getSupportFragmentManager().beginTransaction().replace(R.id.middle, BlankFragment6()).commit()
    }
}