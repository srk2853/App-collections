package com.example.hwfirstapril

import androidx.fragment.app.Fragment

import android.media.MediaPlayer
import android.os.Bundle

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


class BlankFragment4 : Fragment() {
    // TODO: Rename and change types of parameters
   lateinit var medp : MediaPlayer


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        medp = MediaPlayer.create(activity,R.raw.dhoom_machale)
        medp.start()
        return inflater.inflate(R.layout.fragment_blank4, container, false)
    }

    override fun onDestroy() {
        super.onDestroy()
        medp.stop()
        medp.release()
    }

}