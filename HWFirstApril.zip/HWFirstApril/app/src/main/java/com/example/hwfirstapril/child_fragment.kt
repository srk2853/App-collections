package com.example.hwfirstapril

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.fragment.app.Fragment

class ChildFragment : Fragment(R.layout.fragment_child) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val root = view.findViewById<FrameLayout>(R.id.rootLayout)

        root.setOnClickListener {
            Toast.makeText(
                requireContext(),
                "Fragment clicked",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}