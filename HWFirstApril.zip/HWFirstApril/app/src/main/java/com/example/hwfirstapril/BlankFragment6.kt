package com.example.hwfirstapril

import android.media.MediaPlayer
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import android.widget.ImageView

class BlankFragment6 : Fragment() {
    lateinit var medram : MediaPlayer
    lateinit var animn : Animation
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        animn = AnimationUtils.loadAnimation(activity,R.anim.animation_do)

        val vv = inflater.inflate(R.layout.fragment_blank6 ,container,false)

        val i = vv.findViewById<ImageButton>(R.id.ram)
        i.startAnimation(animn)


        medram = MediaPlayer.create(activity,R.raw.ram)
        medram.start()
        return vv
    }

    override fun onDestroy() {
        super.onDestroy()
        medram.stop()
        medram.release()
    }
}