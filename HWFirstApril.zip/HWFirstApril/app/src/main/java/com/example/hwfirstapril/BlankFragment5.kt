package com.example.hwfirstapril

import android.media.MediaPlayer
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


class BlankFragment5 : Fragment() {
    // TODO: Rename and change types of parameters
   lateinit var medp : MediaPlayer


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        medp = MediaPlayer.create(activity,R.raw.lion_roaring)
        medp.start()
        return inflater.inflate(R.layout.fragment_blank5, container, false)
    }

    override fun onDestroy() {
        super.onDestroy()
        medp.stop()
        medp.release()
    }

}