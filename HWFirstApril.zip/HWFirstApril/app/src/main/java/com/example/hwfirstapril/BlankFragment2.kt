package com.example.hwfirstapril

import android.media.MediaPlayer
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import java.util.zip.Inflater

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [BlankFragment2.newInstance] factory method to
 * create an instance of this fragment.
 */
class BlankFragment2 : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    lateinit var mediplay : MediaPlayer
    lateinit var animn : Animation
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        animn = AnimationUtils.loadAnimation(activity,R.anim.animation_do)
        val vv = inflater.inflate(R.layout.fragment_blank2,container,false)
        val i = vv.findViewById<ImageButton>(R.id.cow)
        i.startAnimation(animn )

        mediplay = MediaPlayer.create(activity,R.raw.cow_boy)
        mediplay.start()
        return vv
    }

    override fun onDestroy() {
        super.onDestroy()
        mediplay.stop()
        mediplay.release()
    }

}