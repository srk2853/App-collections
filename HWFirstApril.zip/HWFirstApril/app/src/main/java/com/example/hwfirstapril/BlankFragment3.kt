package com.example.hwfirstapril

import android.media.MediaPlayer
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageButton

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class BlankFragment3 : Fragment() {
    // TODO: Rename and change types of parameters
   lateinit var medplay : MediaPlayer
   lateinit var anim : Animation

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
       anim = AnimationUtils.loadAnimation(activity,R.anim.animation_do)
        val vv = inflater.inflate(R.layout.fragment_blank3,container,false)
        val i = vv.findViewById<ImageButton>(R.id.dog)
        i.startAnimation(anim)

        medplay = MediaPlayer.create(activity,R.raw.kutta)
        medplay.start()
        return inflater.inflate(R.layout.fragment_blank3, container, false)
    }

    override fun onDestroy() {
        super.onDestroy()
        medplay.stop()
        medplay.release()
    }

}