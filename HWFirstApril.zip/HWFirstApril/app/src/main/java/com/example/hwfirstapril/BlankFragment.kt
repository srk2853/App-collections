package com.example.hwfirstapril

import android.media.MediaPlayer
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageButton


class BlankFragment : Fragment() {

    lateinit var mediaply : MediaPlayer
    lateinit var animn : Animation

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        animn = AnimationUtils.loadAnimation(activity,R.anim.animation_do)

        val vv = inflater.inflate(R.layout.fragment_blank,container,false)

        //Find ImageButton inside fragment layout
        val i = vv.findViewById<ImageButton>(R.id.cat)
        i.startAnimation(animn)
        mediaply = MediaPlayer.create(activity,R.raw.meow_meow_meow_meow)

        mediaply.start()

        return vv
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaply.stop()
        mediaply.release()
    }

}