package com.example.recycleit

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recycleit.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var bd : ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        bd= ActivityMainBinding.inflate(layoutInflater)
        setContentView(bd.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val itemList = listOf(
            ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)  , ItemData(android.R.drawable.ic_menu_camera, "Camera", 1, false),
            ItemData(android.R.drawable.ic_menu_compass, "Compass", 2, true),
            ItemData(android.R.drawable.ic_menu_directions, "Directions", 3, false),
            ItemData(android.R.drawable.ic_menu_gallery, "Gallery", 1, true),
            ItemData(android.R.drawable.ic_menu_manage, "Manage", 0, false)
        )

        bd.recyid.layoutManager = LinearLayoutManager(this)
        bd.recyid.adapter = smr(itemList)


    }
}