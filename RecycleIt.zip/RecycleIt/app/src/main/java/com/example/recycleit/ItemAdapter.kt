package com.example.recycleit

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Adapter
import com.example.recycleit.ItemAdapter.ViewHoldr
import com.example.recycleit.databinding.ItemRecyclerBinding

/*
class ItemAdapter(itemList: List<ItemData>) : RecyclerView.Adapter<ItemAdapter.ViewHoldr>() {
    class ViewHoldr : : RecyclerView.ViewHolder() {

    }

}
*/

// RecyclerView Adapter class
class ItemAdapter(private val itemList: List<ItemData>) : Adapter<ViewHoldr>() {

    // ViewHolder class to hold the reference of each view in item_recycler.xml
    class ViewHoldr(val binding: ItemRecyclerBinding) : RecyclerView.ViewHolder(binding.root)

    // Called when RecyclerView needs a new ViewHolder to represent an item
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        // Inflate the item layout using ViewBinding
        val binding = ItemRecyclerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHoldr(binding) // Return the ViewHolder object
    }

    // Called to bind data to the views inside each item of RecyclerView
    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
        val item = itemList[position] // Get the item data at the current position
        val context = holder.itemView.context // Get the context of the view
        val b = holder.binding // Access ViewBinding for convenience

        // Set the icon image from resources
        b.itemIcon.setImageResource(item.icon)

        // Set the title text
        b.itemTitle.text = item.title

        // Set the quantity number
        b.tvQuantity.text = item.quantity.toString()

        // Set the switch state (ON/OFF)
        b.itemSwitch.isChecked = item.isChecked

        // Click listener for Title
        b.itemTitle.setOnClickListener {
            Toast.makeText(context, "Title Clicked: ${item.title}", Toast.LENGTH_SHORT).show()
        }

        // Click listener for Icon
        b.itemIcon.setOnClickListener {
            Toast.makeText(context, "Icon Clicked: ${item.title}", Toast.LENGTH_SHORT).show()
        }

        // Click listener for Sample Button
        b.itemButton.setOnClickListener {
            Toast.makeText(context, "Button Clicked: ${item.title}", Toast.LENGTH_SHORT).show()
        }

        // Listener for Switch Toggle (ON/OFF)
        b.itemSwitch.setOnCheckedChangeListener { _, isChecked ->
            Toast.makeText(context, "Switch Clicked: ${item.title}, State: $isChecked", Toast.LENGTH_SHORT).show()
        }

        // Click listener for Plus Button (Increase Quantity)
        b.btnPlus.setOnClickListener {
            item.quantity++ // Increase the quantity
            b.tvQuantity.text = item.quantity.toString() // Update the quantity text
            Toast.makeText(context, "Increased: ${item.title}, Quantity: ${item.quantity}", Toast.LENGTH_SHORT).show()
        }

        // Click listener for Minus Button (Decrease Quantity)
        b.btnMinus.setOnClickListener {
            if (item.quantity > 0) { // Ensure quantity is not negative
                item.quantity-- // Decrease the quantity
                b.tvQuantity.text = item.quantity.toString() // Update the quantity text
                Toast.makeText(context, "Decreased: ${item.title}, Quantity: ${item.quantity}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Returns the total number of items in the list
    override fun getItemCount(): Int = itemList.size
}

class smr (private val itemList: List<ItemData>)  : Adapter<ViewHoldr>(){


    //this will be created once only

    override fun onCreateViewHolder(
        p0: ViewGroup,
        p1: Int
    ): ViewHoldr {
        // Inflate the item layout using ViewBinding
        val binding = ItemRecyclerBinding.inflate(LayoutInflater.from(p0.context), p0, false)
        return ViewHoldr(binding) // Return the ViewHolder object


    }

    //mapping the data , niche se lake bna dega  -

    override fun onBindViewHolder(p0: ItemAdapter.ViewHoldr, p1: Int) {
        val item = itemList[p1] // Get the item data at the current position
        val b = p0.binding // Access ViewBinding for convenience

        // Set the icon image from resources
        b.itemIcon.setImageResource(item.icon)

        // Set the title text
        b.itemTitle.text = item.title

    }
// register the many you want ot create
    override fun getItemCount(): Int = itemList.size


}


/*
class Adap(private val itemList: List<ItemData>) : RecyclerView.Adapter<Adap.ViewHdr>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHdr {


        val binding = ItemRecyclerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHdr(binding)
    }

    override fun onBindViewHolder(
        holder: ViewHdr,
        position: Int
    ) {

        val item = itemList[position]
        val context = holder.item.context
        val b = holder.binding

    }

    override fun getItemCount(): Int {

        return itemList.size
    }

    class ViewHdr(binding: ItemRecyclerBinding): RecyclerView.ViewHolder(binding.root) {

        val binding = binding

        val item = binding.root

    }

}*/
