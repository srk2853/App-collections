package com.example.recycleit

data class ItemData(val icon: Int,
                    val title: String,
                    var quantity: Int,
                    var isChecked: Boolean)