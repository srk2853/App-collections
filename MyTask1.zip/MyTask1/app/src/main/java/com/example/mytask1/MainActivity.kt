package com.example.mytask1

import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalTime

class MainActivity : AppCompatActivity() {
    lateinit var mob : TextView
    lateinit var pwd : TextView
    lateinit var ed : Button
    lateinit var  tv : Button

    lateinit var tv1 : TextView
    lateinit var tv2 : TextView

    lateinit var nxtbtn : Button

    lateinit var lseen : TextView

    lateinit var stf : StringBuffer

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        stf= StringBuffer("")

        mob = findViewById(R.id.mob)
        pwd = findViewById(R.id.pwd)
        ed = findViewById(R.id.edname)
        tv = findViewById(R.id.tv)

        tv1 = findViewById(R.id.tv1)
        tv2 = findViewById(R.id.tv2)

        nxtbtn = findViewById(R.id.button)
        lseen = findViewById(R.id.lseen)


        ed.setOnClickListener {
            Toast.makeText(applicationContext,"Mobile Number " +mob.text+" password "+ pwd.text,
                Toast.LENGTH_SHORT).show()

        }

        tv.setOnClickListener {
          /*  tv1.text = mob.text
            tv2.text = pwd.text*/

            val alertDialog = AlertDialog.Builder(this)

            alertDialog.setTitle("Android is awesome!")
            alertDialog.setMessage("Present Android Engineers!")
            alertDialog.setIcon(android.R.drawable.ic_media_play)

            alertDialog.setPositiveButton("ok",null)
            alertDialog.setNegativeButton("nope",null)
            alertDialog.setNeutralButton("cancel",null)
            alertDialog.show()

        }

        nxtbtn.setOnClickListener {

            val intet = Intent(this, MainActivity2::class.java)
            intet.putExtra("valone",mob.text.toString())
            startActivity(intet)

            val smsman = SmsManager.getDefault()

            smsman.sendTextMessage(mob.text.toString(),
                null,pwd.text.toString(),null,
                null)

        }



    }

    //this function is just for reference we are not using it

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.burgerdots,menu)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
      /*
        if(item.itemId == R.id.orderid){

            Toast.makeText(applicationContext,"order clicked", Toast.LENGTH_LONG).show()

        }

       */

        when(item.itemId){
            R.id.orderid -> Toast.makeText(applicationContext,"order clicked",Toast.LENGTH_LONG).show()
            R.id.settingid -> Toast.makeText(applicationContext,"Setting clicked", Toast.LENGTH_LONG).show()
            R.id.logoutid -> Toast.makeText(applicationContext,"logout clicked", Toast.LENGTH_LONG).show()
            R.id.instantid -> Toast.makeText(applicationContext,"instant id clicked", Toast.LENGTH_LONG).show()

        }

        return super.onOptionsItemSelected(item)
    }




    override fun onStart() {
        super.onStart()

    }


    override fun onResume() {
        super.onResume()

       var currenttime = System.currentTimeMillis()

        stf.append(" ❤️Online \n")
        lseen.text = stf.toString()


    }


    lateinit var currentTime : String
    override fun onPause() {
        super.onPause()

        currentTime = java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(java.util.Date())

        stf.append("Last seen  ${currentTime} \n")
        lseen.text = stf.toString()

    }















    fun sendSMS(phoneNo: String?, msg: String?) {
        try {
            val smsManager: SmsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNo, null, msg, null, null)
            Toast.makeText(
                getApplicationContext(), "Message Sent",
                Toast.LENGTH_LONG
            ).show()
        } catch (ex: Exception) {
            Toast.makeText(
                getApplicationContext(), ex.message.toString(),
                Toast.LENGTH_LONG
            ).show()
            ex.printStackTrace()
        }
    }
}
