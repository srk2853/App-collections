package com.example.hw30thmarch

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class MainActivity : AppCompatActivity() {
    lateinit var wbtn : Button
    lateinit var cbtn : Button
    lateinit var sbtn : Button
    lateinit var cobtn : Button
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        wbtn = findViewById(R.id.wbtn)
        cbtn = findViewById(R.id.cbtn)
        sbtn = findViewById(R.id.sbtn)
        cobtn = findViewById(R.id.cobtn)


        wbtn.setOnClickListener({ val intent = packageManager.getLaunchIntentForPackage("com.whatsapp")
            if(intent != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "Whatsapp Not Installed", Toast.LENGTH_SHORT).show()
            }
        })

        cbtn.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            try {
                startActivity(intent)
            }catch (e : ActivityNotFoundException){
                Toast.makeText(this,"Camera app not found", Toast.LENGTH_SHORT).show()
            }
        }

        sbtn.setOnClickListener {

            startActivityForResult(Intent(android.provider.Settings.ACTION_SETTINGS),0)
        }

        cobtn.setOnClickListener {
            val it =  Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
            startActivity(it)
        }



    }
}