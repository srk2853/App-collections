package com.example.forminterface

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var name : EditText
    lateinit var mobno : EditText

    lateinit var addtxt : EditText

    lateinit var mailtxt : EditText

    lateinit var cbox : CheckBox

    lateinit var regbtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        name = findViewById(R.id.nametxt)
        mobno = findViewById(R.id.mobtxt)
        addtxt = findViewById(R.id.addtxt)
        mailtxt = findViewById(R.id.mailtxt)
        regbtn = findViewById(R.id.regbtn)
        cbox = findViewById(R.id.attac)

        Log.i("abcd123","oncreate executed")





        regbtn.setOnClickListener {
            if(cbox.isChecked()){

                        var intent = Intent(this,ShowDetails::class.java)
                        intent.putExtra("nami",name.text.toString())

                        intent.putExtra("mobi",mobno.text.toString())
                        intent.putExtra("addre",addtxt.text.toString())
                        intent.putExtra("semail",mailtxt.text.toString())


                        startActivity(intent)
            }else{
                    val aldialog = AlertDialog.Builder(this)
                    aldialog.setMessage("You should agree to Terms & Conditions")
                    aldialog.setNegativeButton("Error",null)
                    aldialog.show()
                }

        }




    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.burgerdots,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {


        if (item.itemId==R.id.orderid) {
            Toast.makeText(applicationContext, "order clicked!", Toast.LENGTH_LONG).show()
        }

        when(item.itemId){
            R.id.orderid ->  Toast.makeText(applicationContext, "order clicked!", Toast.LENGTH_LONG).show()

            R.id.orderid -> ""
            R.id.orderid -> ""
            R.id.orderid -> ""


        }

        return super.onOptionsItemSelected(item)
    }


    override fun onStart() {
        super.onStart()
        Log.i("abcd123","onstart executed")
    }

    override fun onPause() {
        super.onPause()
        Log.i("abcd123","onPause executed")

    }

    override fun onResume() {
        super.onResume()
        Log.i("abcd123","onResume executed")

    }







}