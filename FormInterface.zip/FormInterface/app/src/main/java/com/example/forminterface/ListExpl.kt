package com.example.forminterface

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ListExpl : AppCompatActivity() {
    lateinit var listvw : ListView

    lateinit var arrayList: ArrayList<String>

    lateinit var adapr : ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_list_expl)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        arrayList = arrayListOf("Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry","Apple", "Banana", "Cherry")

        listvw = findViewById(R.id.lv)

        adapr = ArrayAdapter<String> (this,android.R.layout.simple_list_item_1
        ,arrayList)

        listvw.adapter = adapr


        listvw.setOnItemClickListener {
            parent, view, position, id ->
            val selectedItem = arrayList[position]

            Toast.makeText(
                this,
                "You clicked: $selectedItem",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
