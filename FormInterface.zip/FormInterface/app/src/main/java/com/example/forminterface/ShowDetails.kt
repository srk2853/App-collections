package com.example.forminterface

import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.w3c.dom.Text

class ShowDetails : AppCompatActivity() {
   lateinit var sname : TextView
    lateinit var smobi : TextView
    lateinit var saddress : TextView
    lateinit var semail : TextView
    lateinit var sbtn : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_show_details)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        sname = findViewById(R.id.sname)
        smobi = findViewById(R.id.smob)
        saddress = findViewById(R.id.saddress)
        semail = findViewById(R.id.semail)
        sbtn = findViewById(R.id.sbtn)


        val mobile = intent.getStringExtra("mobi")?: "No data received"

        smobi.text = if(mobile != null){
            "Mobile No : $mobile"

        } else{
            ""
        }

        val name = intent.getStringExtra("nami")?: "No data recieved"

        sname.text = if(name != null){
            "Name : $name"
        }else{
            ""
        }

        val showAdd = intent.getStringExtra("addre")?: "No data received"
        saddress.text = if(showAdd != null){
            "Address : $showAdd"
        }else{
            ""
        }

        val showEmail = intent.getStringExtra("semail")?: "No data received"
        semail.text = if(showEmail != null){
            "Email : $showEmail"
        }else{
            ""
        }

        sbtn.setOnClickListener {

            val smsMan = SmsManager.getDefault()
            smsMan.sendTextMessage(smobi.text.toString(),null,sname.text.toString()+ " Registerd successfully",null,null)

        }






    }
}