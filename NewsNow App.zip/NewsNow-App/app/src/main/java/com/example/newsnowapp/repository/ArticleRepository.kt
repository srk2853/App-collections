package com.example.newsnowapp.repository

import com.example.newsnowapp.data.local.Article
import com.example.newsnowapp.data.local.ArticleDao

class ArticleRepository(private val dao: ArticleDao) {

    suspend fun insert(article: Article) = dao.insert(article)

    suspend fun delete(article: Article) = dao.delete(article)

    fun getBookmarks() = dao.getBookmarks()

    fun isBookmarked(url: String) = dao.isBookmarked(url)

    suspend fun getBookmarksList():List<Article>{
        return dao.getBookmarksList()
    }
}