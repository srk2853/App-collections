package com.example.newsnowapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newsnowapp.data.local.Article
import com.example.newsnowapp.repository.ArticleRepository
import kotlinx.coroutines.launch

class ArticleViewModel(private val repository: ArticleRepository) : ViewModel() {

    fun toggleBookmark(article: Article, isBookmarked: Boolean) {
        viewModelScope.launch {
            if (isBookmarked) {
                repository.delete(article)
            } else {
                repository.insert(article.copy(isBookmarked = true))
            }
        }
    }

    fun isBookmarked(url: String) = repository.isBookmarked(url)
}