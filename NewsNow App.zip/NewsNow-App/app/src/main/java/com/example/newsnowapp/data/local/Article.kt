package com.example.newsnowapp.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "bookmarks")
data class Article(

    @PrimaryKey
    val url: String, //for unique id
    val title: String,
    val author: String?,
    val sourceName: String,
    val description: String?,
    val urlToImage: String?,
    val publishedAt: String,
    val content: String?,
    val category: String,
    val isBookmarked: Boolean = true //always true if stored
)