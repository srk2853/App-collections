package com.example.newsnowapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import androidx.room.Room
import com.example.newsnowapp.data.local.AppDatabase
import com.example.newsnowapp.data.remote.RetrofitClient
import com.example.newsnowapp.repository.ArticleRepository
import com.example.newsnowapp.repository.NewsRepository
import com.example.newsnowapp.ui.navigation.NavGraph
import com.example.newsnowapp.viewmodel.SearchViewModel
import com.example.newsnowapp.viewmodel.NewsViewModelFactory
import com.example.newsnowapp.ui.theme.NewsNowAppTheme
import com.example.newsnowapp.viewmodel.ArticleViewModel
import com.example.newsnowapp.viewmodel.ArticleViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
     
        val apiService = RetrofitClient.api
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "news_db"
        ).build()

        val articleRepository = ArticleRepository(db.articleDao())

        val repository = NewsRepository(
            apiService,
            articleRepository   // ✅ PASS HERE
        )

        val factory = NewsViewModelFactory(repository)


        setContent {
            NewsNowAppTheme {
                val navController = rememberNavController()

                val db = Room.databaseBuilder(
                    applicationContext,
                    AppDatabase::class.java,
                    "news_db"
                ).build()

                val articleRepository = ArticleRepository(db.articleDao())

                val articleViewModel: ArticleViewModel = viewModel(
                    factory = ArticleViewModelFactory(articleRepository)
                )




                Surface(color = MaterialTheme.colorScheme.background) {

                    NavGraph(navController = navController,
                        factory = factory,
                        articleViewModel = articleViewModel
                        )
                }



            }
        }
    }
}
