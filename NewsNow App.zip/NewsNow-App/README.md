# NewsNow App 📰

A modern, high-performance Android application built with **Jetpack Compose** that delivers real-time news using the **NewsAPI.org** service. This project follows the **Clean Architecture** principles and the **MVVM** design pattern.

## 🚀 Features

* **Top Headlines:** Stay updated with the latest news filtered by categories (Business, Technology, Sports, etc.).
* **Global Search:** Find specific articles from the `Everything` endpoint using custom search queries.
* **Detailed View:** Read a brief summary of the news and view high-quality images.
* **In-App WebView:** Seamlessly read the full article within the app using an integrated Android WebView.
* **Modern UI:** Built entirely with Jetpack Compose for a smooth, reactive user interface.

## 🛠 Tech Stack

* **Language:** [Kotlin](https://kotlinlang.org/)
* **UI Framework:** [Jetpack Compose](https://developer.android.com/jetpack/compose)
* **Networking:** [Retrofit](https://square.github.io/retrofit/) & OkHttp
* **Architecture:** MVVM (Model-View-ViewModel)
* **Asynchronous Tasks:** Kotlin Coroutines & Flow
* **Image Loading:** Coil (Recommended for Compose)

## 🏗 Architecture & Data Flow

The app is organized into a layered architecture to ensure scalability and testability:

1.  **Retrofit Interface:** Defines endpoints for `top-headlines` and `everything`.
2.  **Repository Layer:** Acts as the single source of truth, handling API calls and data mapping.
3.  **ViewModel:** Manages the UI state and handles business logic via Coroutines.
4.  **UI (Compose):** Three main screens (Home, Search, Detail) that react to ViewModel state changes.

## 🔑 Setup & Installation

To protect sensitive information, this project uses the **Secrets Gradle Plugin**.

1.  **Clone the repository:**
    ```bash
    git clone [https://github.com/RanjitRajNahak/NewsNow-App.git](https://github.com/RanjitRajNahak/NewsNow-App.git)
    ```
2.  **Get an API Key:** Register at [NewsAPI.org](https://newsapi.org/) to get your free API key.
3.  **Secure your Key:**
    * Locate your `local.properties` file in the root directory.
    * Add your key at the bottom: `NEWS_API_KEY=your_actual_api_key_here`.
4.  **Build the Project:** Sync Gradle in Android Studio and run the app.
