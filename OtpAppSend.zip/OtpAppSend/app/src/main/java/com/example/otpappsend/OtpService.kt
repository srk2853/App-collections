package com.example.otpappsend



import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.os.postDelayed

import kotlin.random.Random

class OtpService : Service() {

    private val binder = LocalBinder()
    private val handler = Handler(Looper.getMainLooper())
    private val CHANNEL_ID = "OTP_POPUP_CHANNEL"
    private val NOTIFICATION_ID = 1


    inner class  LocalBinder : Binder(){
        fun getService() : OtpService = this@OtpService
    }

    override fun onBind(intent: Intent): IBinder  = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        createNotificationChannel()

        //Initial notification for Foreground services requirement
        val notification = buildNofication("Initialising OTP ....")

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE){
            startForeground(NOTIFICATION_ID,notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        }else {
            startForeground(NOTIFICATION_ID,notification)
        }

        startOtpGenerator()
        return START_STICKY  //START_STICKY tells Android:  “If you kill my service, please restart it automatically
    }

    private fun startOtpGenerator(){
        handler.post(object : Runnable{
            override fun run(){
                val otp = Random.nextInt(100000,9999999).toString()
                updateNotification(otp)
                handler.postDelayed(this,2000) // repeat every 3 seconds
            }
        } )
    }

    private fun updateNotification(otp: String){
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        //notify() with high priority trigger the pop up
        manager.notify(NOTIFICATION_ID,buildNofication("Your new OTP : $otp"))
    }

    private fun buildNofication(message : String): Notification{
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,0,intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this,CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("OTP Alert")
            .setContentText(message)
            .setOngoing(true)//Makes notification non‑swipeable


            .setPriority(NotificationCompat.PRIORITY_HIGH) //required for pop up
            .setDefaults(Notification.DEFAULT_ALL) //sound vibrate triggers peak
            .setContentIntent(pendingIntent) //Action when user taps notification
            .setFullScreenIntent(pendingIntent,true) // forces headsup display //Enables sound, vibration, lights
            //. setOnlyAlertOnce(true)  <-- REMOVED so it pops up every 3 seconds
            .build()

    }

    private fun  createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val channel = NotificationChannel(
                CHANNEL_ID,
                "OTP Notifications",
                NotificationManager.IMPORTANCE_HIGH //High importance for popup
            )
            channel.description = "Channel for popping up OTPs"
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }


}