package com.example.otpappsend
import android.content.*
import android.os.*
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

// REMOVED: java.util.jar.Manifest (This was causing issues with permissions)

class MainActivity : AppCompatActivity() {
    private var mService : OtpService? = null
    private var mBound = false

    private val connection = object : ServiceConnection{
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as OtpService.LocalBinder
            mService = binder.getService()
            mBound= true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            mBound = false
        }


    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Make sure your XML root layout has android:id="@+id/main"
        val rootView = findViewById<android.view.View>(android.R.id.content)
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //request permission for Android 13+
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                1
            )
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            val intent = Intent(this, OtpService::class.java)
            //Fix- version check for startForegroundServicee(APT26+)

            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                    startForegroundService(intent)
            }else{
                startService(intent)
            }

            bindService(intent,connection, Context.BIND_AUTO_CREATE)
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            if(mBound){
                unbindService(connection)
                mBound= false

            }
            //stop the service completly
            stopService(Intent(this, OtpService::class.java))
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        //Good practice to unbind if the activity is destroyed to prevent leaks
        if(mBound){
            unbindService(connection)
            mBound  = false
        }
    }



}