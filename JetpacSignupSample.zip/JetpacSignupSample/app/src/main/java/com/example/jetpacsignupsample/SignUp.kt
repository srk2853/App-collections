package com.example.jetpacsignupsample

import android.util.Patterns
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController


@Composable
fun SignUpScreen(navController: NavHostController) {

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    var nameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }

    var passwordVisible by remember { mutableStateOf(false) }

    fun validateInputs(): Boolean {
        nameError = when {
            name.isBlank() -> "Name is required"
            name.length < 3 -> "Name must be at least 3 characters"
            else -> null
        }

        emailError = when {
            email.isBlank() -> "Email is required"
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Enter a valid email"
            else -> null
        }

        passwordError = when {
            password.isBlank() -> "Password is required"
            password.length < 6 -> "Password must be at least 6 characters"
            else -> null
        }

        return nameError == null && emailError == null && passwordError == null
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFFFA726), Color(0xFFFFD54F))
                )
            )
    ) {

        // Top curved cut shape
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Color.White, shape = RoundedCornerShape(bottomStart = 100.dp))
        )

        Card(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 80.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(30.dp),
            elevation = CardDefaults.cardElevation(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {

            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "App Logo",
                    modifier = Modifier
                        .size(80.dp)
                        .padding(top = 8.dp),
                    contentScale = ContentScale.Fit
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Sign Up",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = poppinsFont
                )

                Spacer(modifier = Modifier.height(20.dp))

                CustomTextField(
                    hint = "Name",
                    value = name,
                    onChange = {
                        name = it
                        if (nameError != null) nameError = null
                    },
                    errorMessage = nameError,
                    keyboardType = KeyboardType.Text
                )

                CustomTextField(
                    hint = "Email",
                    value = email,
                    onChange = {
                        email = it
                        if (emailError != null) emailError = null
                    },
                    errorMessage = emailError,
                    keyboardType = KeyboardType.Email
                )

                CustomTextField(
                    hint = "Create Password",
                    value = password,
                    onChange = {
                        password = it
                        if (passwordError != null) passwordError = null
                    },
                    errorMessage = passwordError,
                    isPassword = true,
                    passwordVisible = passwordVisible,
                    onPasswordToggle = { passwordVisible = !passwordVisible },
                    keyboardType = KeyboardType.Password
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (validateInputs()) {
                            // Proceed with signup
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFFB300)
                    )
                ) {
                    Text("Sign Up", color = Color.Black)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("Or sign up using", fontSize = 12.sp)

                Spacer(modifier = Modifier.height(15.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    SocialIcon(
                        painter = painterResource(id = R.drawable.google),
                        backgroundColor = Color.White
                    )
                    SocialIcon(
                        painter = painterResource(id = R.drawable.facebook),
                        backgroundColor = Color.White
                    )
                    SocialIcon(
                        painter = painterResource(id = R.drawable.twitter),
                        backgroundColor = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Already have an account? Login",
                    fontSize = 12.sp,
                    modifier = Modifier.clickable {
                        navController.navigate("login") {
                            popUpTo("signup") { inclusive = true }

                        }
                    }
                )
            }
        }
    }
}