package com.example.myapp2

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var btn : Button // Declaration above oncreate // D
    lateinit var btna : Button
    lateinit var btnb : Button
    lateinit var btnc : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        btn = findViewById(R.id.Button)
        btna = findViewById(R.id.button2)
        btnb = findViewById(R.id.button3)
        btnc = findViewById(R.id.button4)

        btn.setOnClickListener {
            Toast.makeText(applicationContext,
                "Everything is Happening Perfectly!",
                Toast.LENGTH_LONG).show()
        }
        btna.setOnClickListener {
            Toast.makeText(applicationContext,
                    "BtnA clicked",
                    Toast.LENGTH_LONG
                    ).show()
        }
        btnb.setOnClickListener {
            Toast.makeText(applicationContext,
                "BtnB clicked",
                Toast.LENGTH_LONG
            ).show()
        }
        btnc.setOnClickListener {
            Toast.makeText(applicationContext,
                    "BtnC clicked",
                     Toast.LENGTH_LONG
                ).show()
        }



    }
}