package com.example.navday1cw2

import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.navday1cw2.ui.theme.NavDay1Cw2Theme
import java.nio.file.WatchEvent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Home()

        }
    }
}


@Composable
fun Home(){
    var name by remember { mutableStateOf("") }
    var mob by remember { mutableStateOf(value = "") }
    var address by remember { mutableStateOf(value = "") }
    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize()
    ) {
        TextField( value = name,
            onValueChange = { name = it },
            label =  {Text("Name")}

            )

        TextField(value = mob,
            onValueChange = { mob = it },
            label = {Text("Phone")}

            )

        TextField(value = address,
            onValueChange = { address = it },
            label = {Text("Address")}

            )

    }

    Row(

        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize().padding(bottom = 214.dp),
        verticalAlignment = Alignment.Bottom
    ) {

        Button(onClick = {

        }) {
            Text("Button1")
        }

        Spacer( modifier = Modifier.width(7.dp))
        Button(onClick = {

        }) {
            Text("Button2")
        }
        Spacer(modifier = Modifier.width(7.dp))
        Button( onClick = {

        }) {
            Text("Button3")
        }
    }

}