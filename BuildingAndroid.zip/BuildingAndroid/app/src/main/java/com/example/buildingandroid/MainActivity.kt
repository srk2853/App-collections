package com.example.buildingandroid

import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var myre : MyReceiver

    lateinit var inte : Intent


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val filter = IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED)

        myre = MyReceiver()
        //this is for receiver
        registerReceiver(myre,filter )

        // this is for service
        inte = Intent(this, MyService::class.java)

    }

    //creating two button start and stop and just by clicking starting and stoping services
    fun srt(view: View) {
        startService(inte)
    }
    fun stp(view: View) {
        stopService(inte)
    }
}