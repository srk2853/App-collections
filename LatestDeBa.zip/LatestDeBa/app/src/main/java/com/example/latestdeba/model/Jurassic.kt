package com.example.latestdeba.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Jurassic(
    @PrimaryKey(autoGenerate = true)
    var Jid: Int = 0,

    @ColumnInfo(name = "JName")  // column name 1
    var JName : String,


    @ColumnInfo(name = "JMobile")  // column name 2
    var JMobile : String,


    @ColumnInfo(name = "JAddress")  // column name 3
    var JAddress : String
)