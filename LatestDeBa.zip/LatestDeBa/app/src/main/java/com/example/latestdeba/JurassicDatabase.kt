package com.example.latestdeba

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.latestdeba.model.Jurassic


@Database(entities = [Jurassic::class], version = 1)
abstract class JurassicDatabase : RoomDatabase() {
    abstract fun jurassicDao(): JurassicDao
}