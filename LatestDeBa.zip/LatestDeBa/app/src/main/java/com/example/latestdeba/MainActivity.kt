package com.example.latestdeba

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.room.Room
import com.example.latestdeba.model.Jurassic
import com.example.latestdeba.viewmodel.JurassicViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {



          /*  val scp = rememberCoroutineScope()
            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxSize()



            ){

                val db = Room.databaseBuilder(
                    applicationContext,
                    JurassicDatabase::class.java,
                    "BusDB"
                ).build()

                val repo = JurassicRepository(db.jurassicDao())

                val vm = JurassicViewModel(repo)

                Button({

                    scp.launch {
                        vm.abc(Jurassic(0, "dino", "65", "earth"))
                    }


                }) {
                    Text("Save Jurassic")
                }

                Button({

                    scp.launch {



                       // val add = db.jurassicDao().getAddress("Sambha")

                        val add2 = db.jurassicDao().getAddress("sambha")
                       // Log.d("abcd123", "onCreate: $add")
                        val a = "name: ${add2.JName} id = ${add2.Jid}"
                        Log.d("abcd123", "onCreate: $a")




                    }

                }) {
                    Text("Get Jurassic Data")
                }
            }*/

            Greeting()



        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun Greeting() {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            var s by remember { mutableStateOf("")   }
            var s2 by remember { mutableStateOf("")   }
            var s3 by remember { mutableStateOf("")   }
            Text(text = s2,Modifier.testTag("tv"))
            OutlinedTextField(value = s, onValueChange = {s=it}, placeholder = {
                Text(text = "one")
            },modifier=Modifier.testTag("one"))
            OutlinedTextField(value = s3, onValueChange = {s3=it}, placeholder = {
                Text(text = "two")
            },modifier=Modifier.testTag("two"))
            Button(onClick = {
                s2=s

                s2=  add(s2,s3).toString()
            }) {
                Text(text = "display")
            }
        }
    }

    fun add(a:String,b:String):Int{
        var x:Int =0

        x= a.toInt()+ b.toInt()

        return x
    }
}

