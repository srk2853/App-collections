package com.example.latestdeba

import com.example.latestdeba.model.Jurassic
import com.example.latestdeba.viewmodel.JurassicViewModel

class JurassicRepository(var dao: JurassicDao) {


    suspend fun saveju(jurassic: Jurassic){

        dao.saveJurassic(jurassic)

    }


}