package com.example.latestdeba

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.latestdeba.model.Jurassic

@Dao
interface JurassicDao {
    @Insert
    suspend fun saveJurassic(jurassic: Jurassic)

//    @Query ("select JAddress from Jurassic where JName = :name")
//    suspend fun getAddress( name: String) : String

   // to get all the data

       @Query ("select * from Jurassic where JName = :name")
       suspend fun getAddress( name: String) : Jurassic

}