package com.example.latestdeba.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.latestdeba.model.Jurassic
import com.example.latestdeba.JurassicDatabase
import com.example.latestdeba.JurassicRepository
import kotlinx.coroutines.launch



class JurassicViewModel(val repository: JurassicRepository) : ViewModel() {

    fun abc(jurassic: Jurassic){


        viewModelScope.launch {

          //  val singleJurassicData = Jurassic(0, "Sambha", "98458438", "bindekhalpur")

            repository.saveju(jurassic)



        }

    }
}