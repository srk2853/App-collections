package com.example.fragmtsinandroid

import android.media.MediaPlayer
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView

class BlankFragment2 : Fragment() {


    lateinit var animtn : Animation

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        animtn = AnimationUtils.loadAnimation(activity,R.anim.rotatecode)


        val vw = inflater.inflate(R.layout.fragment_blank2, container, false)

        val i = vw.findViewById<ImageView>(R.id.imageView)

        i.startAnimation(animtn)

        val mediaply = MediaPlayer.create(activity,R.raw.saare_jahan_se_acha)

        mediaply.start()

       // mediaply.pause()

        //mediaply.stop()

        return vw

    }

}