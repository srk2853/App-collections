package com.example.fragmtsinandroid

import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentTransaction

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    fun one(view: View) {
        supportFragmentManager.beginTransaction().replace(R.id.frid, BlankFragment()).commit()
    }
    fun two(view: View) {
        supportFragmentManager.beginTransaction().replace(R.id.frid, BlankFragment2()).commit()

    }

    fun three(view: View) {
        supportFragmentManager.beginTransaction().replace(R.id.frid, BlankFragment3()).commit()

    }
}