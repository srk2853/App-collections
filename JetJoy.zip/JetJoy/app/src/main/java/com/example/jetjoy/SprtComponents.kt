package com.example.jetjoy

import androidx.compose.runtime.Composable

class SprtComponents {


}

@Composable
fun settings(){

    // this is settings ui

}