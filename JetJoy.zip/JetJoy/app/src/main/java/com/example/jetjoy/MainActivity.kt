
package com.example.jetjoy

import android.os.Bundle
import android.provider.CalendarContract
import android.widget.RatingBar
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            Column(modifier = Modifier.fillMaxSize()
                .background(Color.Magenta),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,

            ) {


               abc()
               profile()

                settings()

                Text("hi")

                Button(onClick = {}) {
                    var name by remember { mutableStateOf("def val") }

                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        TextField(value = name,onValueChange = {
                            name=it
                        })
                        Text("Awesome!", fontSize = 32.sp,
                            color =  Color(0xFF9C27B0),
                            textAlign = TextAlign.End,

                            )
                        Button(onClick = {
                            Toast.makeText(applicationContext,"", Toast.LENGTH_LONG).show()
                        }
                            ,
                            shape =  RoundedCornerShape(16.dp)) {
                            Text("great")
                        }
                        abc()
                    }

                }

            }
        }
    }

    @Composable
    fun abc(){
        var name by remember { mutableStateOf("def val") }
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            TextField(value = name,onValueChange = {
                name=it
            })

            Text("Awesome!", fontSize = 32.sp,
                color =  Color(0xFF9C27B0),
                textAlign = TextAlign.End,

                )
            Button(onClick = {
                Toast.makeText(applicationContext,"", Toast.LENGTH_LONG).show()
            }
                ,
                shape =  RoundedCornerShape(16.dp)) {
                Text("great")
            }
            abc()
        }
    }

    @Composable
    fun profile(){
        Column() {
            Image(painter = painterResource(android.R.drawable.ic_menu_camera),"")
            Text("Name : Ranjith")
            Text("Designation : Teacher")
        }
    }
}

