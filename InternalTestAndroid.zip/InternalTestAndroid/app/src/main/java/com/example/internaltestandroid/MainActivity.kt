package com.example.internaltestandroid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.internaltestandroid.ui.theme.InternalTestAndroidTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            InternalTestAndroidTheme {

                main()
            }
        }
    }
}


fun main() = runBlocking {
    launch {
        delay(1000L)
        println("Hello from Coroutine")
    }
    println("Hello from Main")
}

/*
1. fun main()
Kotlinfun main() = runBlocking {Show more lines

This is the starting point of the program.
runBlocking:

Starts a coroutine scope
Blocks the current thread (main thread) until everything inside finishes
Mainly used for testing, learning, or console programs
❌ Not recommended in Android UI code



👉 Think of runBlocking as:

“Start coroutines and wait for them to finish before exiting main.”


2. launch { ... }
Kotlinlaunch {Show more lines

launch creates a new coroutine
Runs concurrently with the rest of the code
Does not block the main thread

👉 A coroutine is lightweight compared to a thread.

3. delay(1000L)
Kotlindelay(1000L)Show more lines

Suspends the coroutine for 1 second
Does NOT block the thread
Allows other code to execute

✅ delay is a suspending function
❌ Thread.sleep() would block the thread

4. println("Hello from Coroutine")
Kotlinprintln("Hello from Coroutine")Show more lines

Executes after 1 second
Runs inside the coroutine


5. Immediate main execution
Kotlinprintln("Hello from Main")Show more lines

Executes immediately
Does NOT wait for the coroutine to finish


Execution Order (Very Important)
Output:
Hello from Main
Hello from Coroutine

Why?

launch starts coroutine → goes to background
Main thread continues immediately
"Hello from Main" prints first
After 1 second → coroutine resumes
"Hello from Coroutine" prints
 */