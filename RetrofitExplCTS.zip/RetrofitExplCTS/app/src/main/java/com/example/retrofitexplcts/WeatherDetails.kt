package com.example.retrofitexplcts

data class WeatherDetails(
    val weather: List<Weather>?= null,
)
