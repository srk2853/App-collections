package com.example.retrofitexplcts

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface Deba {



    //defining the endpoints
    @GET("weather/")
    suspend fun getWeatherByCity(
        @Query("q") cityName: String,
        @Query("appid") apiKey: String
    ) : WeatherDetails

    companion object {
        var api: Deba? = null
        fun getInstance() : Deba {
            api = Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(Deba::class.java)
            return api!!
        }
    }
}

//for reference only
//https://api.openweathermap.org/data/2.5/weather?q=delhi&appid=a6ea090d1f474d6abdee5db6552ff501