package com.example.movieretrotask1



import com.google.gson.annotations.SerializedName

data class Movies(
    val ok: Boolean,

    @SerializedName("description")
    val descr: List<Movie>,

    @SerializedName("error_code")
    val errcode: Int
)

data class Movie(

    @SerializedName("#TITLE")
    val title: String,

    @SerializedName("#YEAR")
    val year: Int,

    @SerializedName("#IMDB_ID")
    val imdbId: String,

    @SerializedName("#RANK")
    val rank: Int,

    @SerializedName("#ACTORS")
    val actors: String,

    @SerializedName("#AKA")
    val aka: String,

    @SerializedName("#IMDB_URL")
    val imdbUrl: String,

    @SerializedName("#IMDB_IV")
    val imdbIv: String,

    @SerializedName("#IMG_POSTER")
    val imgPoster: String,

    @SerializedName("photo_width")
    val photoWidth: Int,

    @SerializedName("photo_height")
    val photoHeight: Int
)

