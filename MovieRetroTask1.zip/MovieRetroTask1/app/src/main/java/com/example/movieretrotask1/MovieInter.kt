package com.example.movieretrotask1

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface MovieInter {

    @GET("search/")
    suspend fun getMovieInfoByName(
            @Query("q") movieName: String

    ): Movies


    companion object {
        var api : MovieInter?= null

        fun getInstance() : MovieInter{

            api = Retrofit.Builder()
                .baseUrl("https://imdb.iamidiotareyoutoo.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(MovieInter ::class.java)

            return api!!
        }



    }



}