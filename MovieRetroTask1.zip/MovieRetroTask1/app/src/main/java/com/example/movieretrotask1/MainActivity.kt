package com.example.movieretrotask1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.movieretrotask1.ui.theme.MovieRetroTask1Theme
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {


            var searchText by remember { mutableStateOf("") }
            var result by remember { mutableStateOf<Movies?>(null) }
            var isLoading by remember { mutableStateOf(false) }
            var errorMessage by remember { mutableStateOf<String?>(null) }



            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize().padding(16.dp)
            ) {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = {searchText = it},
                    label = {Text("Enter Movie Name")},
                    modifier = Modifier.fillMaxWidth()
                )


                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        isLoading = true
                        errorMessage = null
                        result = null

                        //coroutine scope

                        kotlinx.coroutines.GlobalScope.launch(
                            kotlinx.coroutines.Dispatchers.Main
                        ) {

                            try {
                                val response = MovieInter
                                    .getInstance()
                                    .getMovieInfoByName(searchText)

                                if(response.descr.isEmpty()){
                                    errorMessage = "No Movie Found"
                                }else{
                                    result = response
                                }
                            } catch (e: Exception){
                                errorMessage = "Something went wrong"
                            }
                            isLoading = false
                        }
                    }
                ) {
                    Text("Search")
                }

                Spacer(modifier = Modifier.height(20.dp))

                //loading
                if(isLoading){
                    Text("Loading..")
                }

                //error
                errorMessage?.let{
                    Text(it,color = Color.Red)
                }

                //result

                result?.descr?.let  {
                    movies ->
                        LazyColumn {
                            items(movies){ movie ->
                                Column(modifier = Modifier.padding(12.dp)) {

                                    AsyncImage(
                                        model = movie.imgPoster,
                                        contentDescription = movie.title,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(250.dp)
                                    )

                                    Text(
                                        text= movie.title,
                                        style = MaterialTheme.typography.titleLarge

                                    )

                                    Text("Year: ${movie.year}")
                                    Text("Actors: ${movie.actors}")
                                    Text("IMDB : ${movie.imdbUrl}")
                                }


                            }
                        }
                }





            }




            }
        }

}



//
//
//LaunchedEffect(Unit) {
//    try {
//        result = MovieInter
//            .getInstance()
//            .getMovieInfoByName("Spider-Man")
//    } catch (e: Exception) {
//        e.printStackTrace()
//    }
//}
//
//
//LazyColumn {
//    items(result?.descr ?: emptyList()) { movie ->
//
//        Column(modifier = Modifier.padding(12.dp)) {
//
//            AsyncImage(
//                model = movie.imgPoster,
//                contentDescription = movie.title,
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(300.dp)
//            )
//
//            Text("Title: ${movie.title}")
//            Text("Year: ${movie.year}")
//            Text("Actors: ${movie.actors}")
//            Text("IMDB: ${movie.imdbUrl}")
//        }
//    }
//}
