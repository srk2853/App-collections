package com.example.app1.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.app1.ui.component.NewsTextField
import com.example.app1.viewmodel.AuthViewModel


// ------------------Sign Up Scratch Basic ----------------
//@Composable
//fun LoginScreen(onSignUpClick: () -> Unit, onLoginSuccess: () -> Unit) {
//    var email by remember { mutableStateOf("") }
//    var password by remember { mutableStateOf("") }
//
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .padding(24.dp)
//            .verticalScroll(rememberScrollState()),
//        horizontalAlignment = Alignment.Start
//    ) {
//        Spacer(modifier = Modifier.height(64.dp))
//
//        // Editorial Headline
//        Text(
//            text = "Welcome back.",
//            style = MaterialTheme.typography.displaySmall.copy(
//                fontWeight = FontWeight.Bold,
//                fontFamily = FontFamily.Serif // Merriweather equivalent
//            ),
//            color = Color(0xFF1A1A1A)
//        )
//        Text(
//            text = "Sign in to catch up on today's headlines.",
//            style = MaterialTheme.typography.bodyLarge,
//            color = Color.Gray,
//            modifier = Modifier.padding(top = 8.dp, bottom = 32.dp)
//        )
//
//        NewsTextField(email, { email = it }, "Email Address")
//        Spacer(modifier = Modifier.height(16.dp))
//        NewsTextField(password, { password = it }, "Password", isPassword = true)
//
//        Text(
//            text = "Forgot Password?",
//            modifier = Modifier.align(Alignment.End).padding(vertical = 8.dp),
//            style = MaterialTheme.typography.labelMedium,
//            color = Color(0xFF1565C0)
//        )
//
//        Spacer(modifier = Modifier.height(24.dp))
//
//        Button(
//            onClick = onLoginSuccess,
//            modifier = Modifier.fillMaxWidth().height(56.dp),
//            shape = RoundedCornerShape(12.dp),
//            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
//        ) {
//            Text("Sign In", fontSize = 16.sp, fontWeight = FontWeight.Bold)
//        }
//
//        Row(
//            modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
//            horizontalArrangement = Arrangement.Center
//        ) {
//            Text("New to NewsNow? ", color = Color.Gray)
//            Text(
//                "Create Account",
//                color = Color(0xFF1565C0),
//                fontWeight = FontWeight.Bold,
//                modifier = Modifier.clickable { onSignUpClick() }
//            )
//        }
//    }
//}
//

//-------------------------Sign Up Modern ----------------------
//@Composable
//fun LoginScreen(onSignUpClick: () -> Unit, onLoginSuccess: () -> Unit) {
//    var email by remember { mutableStateOf("") }
//    var password by remember { mutableStateOf("") }
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(
//                Brush.verticalGradient(
//                    colors = listOf(Color(0xFFF5F7FA), Color(0xFFB8C6DB)) // Subtle professional gradient
//                )
//            )
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(24.dp)
//                .verticalScroll(rememberScrollState()),
//            horizontalAlignment = Alignment.CenterHorizontally
//        ) {
//            Spacer(modifier = Modifier.height(80.dp))
//
//            // Editorial Branding
//            Text(
//                text = "NewsNow",
//                style = MaterialTheme.typography.displaySmall.copy(
//                    fontWeight = FontWeight.ExtraBold,
//                    fontFamily = FontFamily.Serif,
//                    color = Color(0xFF1565C0)
//                )
//            )
//            Text(
//                text = "Insight in your pocket",
//                style = MaterialTheme.typography.bodyMedium,
//                color = Color.Gray
//            )
//
//            Spacer(modifier = Modifier.height(60.dp))
//
//            // Modern Input Fields
//            OutlinedTextField(
//                value = email,
//                onValueChange = { email = it },
//                label = { Text("Email Address") },
//                modifier = Modifier.fillMaxWidth(),
//                shape = RoundedCornerShape(50.dp), // Pill Shape
//                colors = OutlinedTextFieldDefaults.colors(
//                    focusedBorderColor = Color(0xFF1565C0),
//                    unfocusedBorderColor = Color.LightGray,
//                    focusedContainerColor = Color.White,
//                    unfocusedContainerColor = Color.White.copy(alpha = 0.7f)
//                )
//            )
//
//            Spacer(modifier = Modifier.height(16.dp))
//
//            OutlinedTextField(
//                value = password,
//                onValueChange = { password = it },
//                label = { Text("Password") },
//                modifier = Modifier.fillMaxWidth(),
//                shape = RoundedCornerShape(50.dp),
//                visualTransformation = PasswordVisualTransformation(),
//                colors = OutlinedTextFieldDefaults.colors(
//                    focusedBorderColor = Color(0xFF1565C0),
//                    unfocusedBorderColor = Color.LightGray,
//                    focusedContainerColor = Color.White,
//                    unfocusedContainerColor = Color.White.copy(alpha = 0.7f)
//                )
//            )
//
//            TextButton(
//                onClick = { /* Forgot */ },
//                modifier = Modifier.align(Alignment.End)
//            ) {
//                Text("Forgot Password?", color = Color(0xFF1565C0))
//            }
//
//            Spacer(modifier = Modifier.height(24.dp))
//
//            Button(
//                onClick = onLoginSuccess,
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(56.dp),
//                shape = RoundedCornerShape(50.dp),
//                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
//            ) {
//                Text("Login", fontSize = 16.sp, fontWeight = FontWeight.Bold)
//            }
//
//            Spacer(modifier = Modifier.height(16.dp))
//
//            TextButton(onClick = onSignUpClick) {
//                Row {
//                    Text("Don't have an account? ", color = Color.Gray)
//                    Text("Sign Up", color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
//                }
//            }
//        }
//    }
//}


//--------------Sign In Modern Glass Code -------------
//@Composable
//fun LoginScreen(onSignUpClick: () -> Unit, onLoginSuccess: () -> Unit) {
//    var email by remember { mutableStateOf("") }
//    var password by remember { mutableStateOf("") }
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(
//                Brush.verticalGradient(
//                    colors = listOf(Color(0xFFF5F7FA), Color(0xFFB8C6DB))
//                )
//            ),
//        contentAlignment = Alignment.Center
//    ) {
//        // The Glass Container
//        Card(
//            modifier = Modifier
//                .fillMaxWidth(0.9f)
//                .padding(16.dp),
//            shape = RoundedCornerShape(32.dp),
//            colors = CardDefaults.cardColors(
//                containerColor = Color.White.copy(alpha = 0.4f) // Glass effect
//            ),
//            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f))
//        ) {
//            Column(
//                modifier = Modifier
//                    .padding(24.dp)
//                    .verticalScroll(rememberScrollState()),
//                horizontalAlignment = Alignment.CenterHorizontally
//            ) {
//                Text(
//                    text = "NewsNow",
//                    style = MaterialTheme.typography.displaySmall.copy(
//                        fontWeight = FontWeight.ExtraBold,
//                        fontFamily = FontFamily.Serif,
//                        color = Color(0xFF1565C0)
//                    )
//                )
//                Text("Insight in your pocket", color = Color.DarkGray.copy(alpha = 0.7f))
//
//                Spacer(modifier = Modifier.height(40.dp))
//
//                OutlinedTextField(
//                    value = email,
//                    onValueChange = { email = it },
//                    label = { Text("Email Address") },
//                    modifier = Modifier.fillMaxWidth(),
//                    shape = RoundedCornerShape(50.dp),
//                    colors = OutlinedTextFieldDefaults.colors(
//                        focusedContainerColor = Color.White,
//                        unfocusedContainerColor = Color.White.copy(alpha = 0.8f),
//                        focusedBorderColor = Color(0xFF1565C0)
//                    )
//                )
//
//                Spacer(modifier = Modifier.height(16.dp))
//
//                OutlinedTextField(
//                    value = password,
//                    onValueChange = { password = it },
//                    label = { Text("Password") },
//                    modifier = Modifier.fillMaxWidth(),
//                    shape = RoundedCornerShape(50.dp),
//                    visualTransformation = PasswordVisualTransformation(),
//                    colors = OutlinedTextFieldDefaults.colors(
//                        focusedContainerColor = Color.White,
//                        unfocusedContainerColor = Color.White.copy(alpha = 0.8f),
//                        focusedBorderColor = Color(0xFF1565C0)
//                    )
//                )
//
//                Spacer(modifier = Modifier.height(24.dp))
//
//                Button(
//                    onClick = onLoginSuccess,
//                    modifier = Modifier.fillMaxWidth().height(56.dp),
//                    shape = RoundedCornerShape(50.dp),
//                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
//                ) {
//                    Text("Login", fontWeight = FontWeight.Bold)
//                }
//
//                TextButton(onClick = onSignUpClick) {
//                    Row {
//                        Text("Don't have account? ", color = Color.DarkGray)
//                        Text("Sign Up", color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
//                    }
//                }
//            }
//        }
//    }
//}



//perfect Code 1
//---------------------Sign In Page With Glass And App Resize when Keyboard Pop Up -----------------------


//
//@Composable
//fun LoginScreen(onSignUpClick: () -> Unit, onLoginSuccess: () -> Unit) {
//    var email by remember { mutableStateOf("") }
//    var password by remember { mutableStateOf("") }
//    val scrollState = rememberScrollState()
//
//    // Get the keyboard controller
//    val keyboardController = LocalSoftwareKeyboardController.current
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(
//                Brush.verticalGradient(
//                    colors = listOf(Color(0xFFF5F7FA), Color(0xFFB8C6DB))
//                )
//            )
//            .imePadding(),
//        contentAlignment = Alignment.Center
//    ) {
//        Card(
//            modifier = Modifier
//                .fillMaxWidth(0.9f)
//                .padding(16.dp)
//                .fillMaxHeight(0.85f),
//            shape = RoundedCornerShape(32.dp),
//            colors = CardDefaults.cardColors(
//                containerColor = Color.White.copy(alpha = 0.4f)
//            ),
//            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f))
//        ) {
//            Column(
//                modifier = Modifier
//                    .padding(24.dp)
//                    .verticalScroll(scrollState),
//                horizontalAlignment = Alignment.CenterHorizontally,
//                verticalArrangement = Arrangement.Center
//            ) {
//                Text(
//                    text = "NewsNow",
//                    style = MaterialTheme.typography.displaySmall.copy(
//                        fontWeight = FontWeight.ExtraBold,
//                        fontFamily = FontFamily.Serif,
//                        color = Color(0xFF1565C0)
//                    )
//                )
//                Text(
//                    text = "Insight in your pocket",
//                    color = Color.DarkGray.copy(alpha = 0.7f)
//                )
//
//
//                //Component we can create from here to
//
//                Spacer(modifier = Modifier.height(40.dp))
//
//                OutlinedTextField(
//                    value = email,
//                    onValueChange = { email = it },
//                    label = { Text("Email Address") },
//                    modifier = Modifier.fillMaxWidth(),
//                    shape = RoundedCornerShape(50.dp),
//                    colors = OutlinedTextFieldDefaults.colors(
//                        focusedContainerColor = Color.White,
//                        unfocusedContainerColor = Color.White.copy(alpha = 0.8f),
//                        focusedBorderColor = Color(0xFF1565C0)
//                    ),
//                    singleLine = true
//                )
//
//                Spacer(modifier = Modifier.height(16.dp))
//
//                OutlinedTextField(
//                    value = password,
//                    onValueChange = { password = it },
//                    label = { Text("Password") },
//                    modifier = Modifier.fillMaxWidth(),
//                    shape = RoundedCornerShape(50.dp),
//                    visualTransformation = PasswordVisualTransformation(),
//                    colors = OutlinedTextFieldDefaults.colors(
//                        focusedContainerColor = Color.White,
//                        unfocusedContainerColor = Color.White.copy(alpha = 0.8f),
//                        focusedBorderColor = Color(0xFF1565C0)
//                    ),
//                    singleLine = true
//                )
//
//                // Component logic end here
//
//                TextButton(
//                    onClick = { /* Forgot Pass Action */ },
//                    modifier = Modifier.align(Alignment.End)
//                ) {
//                    Text("Forgot Password?", color = Color(0xFF1565C0))
//                }
//
//                Spacer(modifier = Modifier.height(24.dp))
//
//                Button(
//                    onClick = {
//                        // 1. Hide the keyboard
//                        keyboardController?.hide()
//                        // 2. Trigger navigation/success logic
//                        onLoginSuccess()
//                    },
//                    modifier = Modifier.fillMaxWidth().height(56.dp),
//                    shape = RoundedCornerShape(50.dp),
//                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
//                ) {
//                    Text("Login", fontWeight = FontWeight.Bold, fontSize = 16.sp)
//                }
//
//                Spacer(modifier = Modifier.height(16.dp))
//
//                TextButton(onClick = onSignUpClick) {
//                    Row {
//                        Text("Don't have account? ", color = Color.DarkGray)
//                        Text("Sign Up", color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
//                    }
//                }
//            }
//        }
//    }
//}








//Perfect Code 2



//-----------------Reusable Component moderninput kt  use in Login Screen Logic -----------------
@Composable
fun LoginScreen(authViewModel: AuthViewModel,onSignUpClick: () -> Unit, onLoginSuccess: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()
    val keyboardController = LocalSoftwareKeyboardController.current
    val context = LocalContext.current // Used to show Toast messages

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFFF5F7FA), Color(0xFFB8C6DB))
                )
            )
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp)
                //REMOVED  .fillMaxHeight(0.85f) here and replaced .wrapContentHeight() to reduce space between Card And Keyboard Pop Up
                .wrapContentHeight(),
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White.copy(alpha = 0.4f)
            ),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(scrollState),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "NewsNow",
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Serif,
                        color = Color(0xFF1565C0)
                    )
                )
                Text(
                    text = "Insight in your pocket",
                    color = Color.DarkGray.copy(alpha = 0.7f)
                )

                Spacer(modifier = Modifier.height(40.dp))

                // --- Shared Components Start ---
                NewsTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = "Email Address"
                )

                Spacer(modifier = Modifier.height(16.dp))

                NewsTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = "Password",
                    isPassword = true
                )
                // --- Shared Components End ---

                TextButton(
                    onClick = { /* Forgot Pass Action */ },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Forgot Password?", color = Color(0xFF1565C0))
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        keyboardController?.hide()
                        // ✅ FIX: Process the actual database login validation checks
                        authViewModel.login(email, password) { isSuccess, responseMessage ->
                            if (isSuccess) {
                                onLoginSuccess() // Session is saved automatically via VM
                            } else {
                                // Shows Toast for "User Not Registered" or "Incorrect Password"
                                Toast.makeText(context, responseMessage, Toast.LENGTH_SHORT).show()
                            }
                        }
                    },

                    // Disable click action unless the user typed in both inputs
                    enabled = email.isNotEmpty() && password.isNotEmpty(),

                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
                ) {
                    Text("Login", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(onClick = onSignUpClick) {
                    Row {
                        Text("Don't have account? ", color = Color.DarkGray)
                        Text("Sign Up", color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}