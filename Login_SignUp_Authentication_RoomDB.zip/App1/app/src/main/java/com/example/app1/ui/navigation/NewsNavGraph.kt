package com.example.app1.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.app1.ui.screens.LoginScreen
import com.example.app1.ui.screens.SignUpScreen
import com.example.app1.viewmodel.AuthViewModel

object Screen {
    const val Login = "login"
    const val SignUp = "signup"
    const val Home = "home"
}

@Composable
fun NewsNavGraph(
    navController: NavHostController,
    isLoggedIn: Boolean,
    authViewModel: AuthViewModel // <-- 1. Accept it as a parameter here
) {
    NavHost(
        navController = navController,
        startDestination = if (isLoggedIn) Screen.Home else Screen.Login
    ) {
        // 1. Login Screen
        composable(route = Screen.Login) {
            LoginScreen(
                authViewModel = authViewModel,
                onSignUpClick = {
                    navController.navigate(Screen.SignUp)
                },
                onLoginSuccess = {
                    navController.navigate(Screen.Home) {
                        popUpTo(Screen.Login) { inclusive = true }
                    }
                }
            )
        }

        // 2. Sign Up Screen
        composable(route = Screen.SignUp) {
            SignUpScreen(
                authViewModel = authViewModel,
                onBackToLogin = {
                    navController.popBackStack()
                }
            )
        }

        // 3. Home Screen Placeholder
        composable(route = Screen.Home) {
            androidx.compose.foundation.layout.Box(
                modifier = androidx.compose.ui.Modifier.fillMaxSize(),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                androidx.compose.material3.Text(text = "Welcome to Home Screen Placeholder!")
            }
        }
    }
}