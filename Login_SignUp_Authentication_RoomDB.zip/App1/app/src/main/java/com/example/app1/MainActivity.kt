package com.example.app1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.example.app1.ui.navigation.NewsNavGraph
import com.example.app1.ui.theme.App1Theme
import com.example.app1.viewmodel.AuthViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            App1Theme {
                val navController = rememberNavController()

                // This instance has the correct Activity/Application context attachment
                val authViewModel: AuthViewModel = viewModel()

                val isLoggedIn by authViewModel.isLoggedIn.collectAsState(initial = false)

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        NewsNavGraph(
                            navController = navController,
                            isLoggedIn = isLoggedIn,
                            authViewModel = authViewModel // <-- 2. Pass it down here safely
                        )
                    }
                }
            }
        }
    }
}