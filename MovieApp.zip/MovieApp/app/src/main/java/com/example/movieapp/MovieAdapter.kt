package com.example.movieapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MovieAdapter( private  val movieList: List<Movie>,private val onItemClick : (Movie) -> Unit):
    RecyclerView.Adapter<MovieAdapter.MovieViewHolder>()
{
    class MovieViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val title : TextView = view.findViewById(R.id.tvTitle)
        val creator : TextView = view.findViewById(R.id.tvCreator)
        val likes : TextView = view.findViewById(R.id.tvLikes)
        val imgMovie : ImageView = view.findViewById(R.id.imgMovie)
        val imgCreator : ImageView = view.findViewById(R.id.imgCreator)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType:Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_movie,parent,false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = movieList[position]
        holder.title.text = movie.title
        holder.creator.text = movie.creatorName
        holder.likes.text = movie.likes
       // holder.imgMovie.setImageResource(movie.creatorImage)

        holder.itemView.setOnClickListener { onItemClick(movie) }
    }
    override fun getItemCount() = movieList.size

}