package com.example.movieapp

import android.accessibilityservice.GestureDescription

data class Movie(
    val title : String,
    val creatorName : String,
    val likes : String,
    val description: String,
    val rating : String
)
