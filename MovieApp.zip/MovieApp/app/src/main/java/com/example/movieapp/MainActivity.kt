package com.example.movieapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.movieapp.databinding.ActivityMainBinding
import com.google.android.material.bottomsheet.BottomSheetDialog

class MainActivity : AppCompatActivity() {

private lateinit var bd : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        bd = ActivityMainBinding.inflate(layoutInflater)

        setContentView(bd.root)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val movies = listOf(
            Movie("bahubali","S.S Rajamauli","21K likes","An historical movie","4.5/5"),
            Movie("Chennai express","Rohit Shetty","11K likes","A Comedy movie","4.4/5")
        )

        bd.movieRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false)
        bd.movieRecyclerView.adapter = MovieAdapter(movies){
            movie -> showMovieDetailSheet(movie)
        }
    }

    fun showMovieDetailSheet(movie: Movie) {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.layout_bottom_sheet,null)


    }


}