package com.example.navallurnavhost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {

    @Composable
    fun pageone(m: String?){


        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            Text("I am page one  $m")
        }
    }
    @Composable
    fun pagetwo(){
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            Text("I am page two")
        }
    }

    @Composable
    fun Home(rem1: NavHostController) {
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {

            var name by remember { mutableStateOf("") }

            Text("I am Home page")

            TextField(name,{
                name=it
            })

            Button(onClick = {
                rem1.navigate("abc/$name")
            }) {
                Text("good")

            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

         val rem = rememberNavController()

            NavHost(rem, startDestination = "hme") {

                composable("hme") { Home(rem) }

                composable("abc/{bbmm}") {

                   var b = it.arguments?.getString("bbmm")


                    pageone(b)
                }

                composable("xyz") { pagetwo() }


            }

        }
    }
}
